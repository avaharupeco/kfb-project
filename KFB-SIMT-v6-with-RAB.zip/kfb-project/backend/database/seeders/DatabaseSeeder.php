<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // ── USERS (5 ROLE) ────────────────────────────────────
        $users = [
            ['name'=>'Pak Kurnia',     'email'=>'owner@kfb.com',    'role'=>'owner'],
            ['name'=>'Budi Prasetyo',  'email'=>'manager@kfb.com',  'role'=>'manager'],
            ['name'=>'Andi Pratama',   'email'=>'sales@kfb.com',    'role'=>'sales'],
            ['name'=>'Sari Wulandari', 'email'=>'admin@kfb.com',    'role'=>'admin'],
            ['name'=>'Heru Santoso',   'email'=>'produksi@kfb.com', 'role'=>'produksi'],
        ];
        foreach ($users as $u) {
            DB::table('users')->insertOrIgnore([
                ...$u,
                'password'   => Hash::make('password'),
                'is_active'  => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
        $ownerId    = DB::table('users')->where('email','owner@kfb.com')->value('id');
        $managerId  = DB::table('users')->where('email','manager@kfb.com')->value('id');
        $salesId    = DB::table('users')->where('email','sales@kfb.com')->value('id');
        $adminId    = DB::table('users')->where('email','admin@kfb.com')->value('id');
        $produksiId = DB::table('users')->where('email','produksi@kfb.com')->value('id');

        // ── CUSTOMERS ─────────────────────────────────────────
        $customers = [
            ['kode'=>'KFB-2025-001','name'=>'Budi Santoso',   'phone'=>'081111111111','source'=>'instagram','address'=>'Dramaga, Bogor'],
            ['kode'=>'KFB-2025-002','name'=>'Rina Maharani',  'phone'=>'081222222222','source'=>'tiktok',    'address'=>'Cibinong, Bogor'],
            ['kode'=>'KFB-2025-003','name'=>'Agus Widodo',    'phone'=>'081333333333','source'=>'referral',  'address'=>'Pajajaran, Bogor'],
            ['kode'=>'KFB-2025-004','name'=>'Dewi Lestari',   'phone'=>'081444444444','source'=>'whatsapp',  'address'=>'Sentul City, Bogor'],
            ['kode'=>'KFB-2025-005','name'=>'Hendra Gunawan', 'phone'=>'081555555555','source'=>'website',   'address'=>'Tajur Halang, Bogor'],
        ];
        foreach ($customers as $c) {
            DB::table('customers')->insertOrIgnore([...$c, 'created_at'=>now(), 'updated_at'=>now()]);
        }
        $c1 = DB::table('customers')->where('kode','KFB-2025-001')->value('id');
        $c2 = DB::table('customers')->where('kode','KFB-2025-002')->value('id');
        $c3 = DB::table('customers')->where('kode','KFB-2025-003')->value('id');
        $c4 = DB::table('customers')->where('kode','KFB-2025-004')->value('id');
        $c5 = DB::table('customers')->where('kode','KFB-2025-005')->value('id');

        // ── DEALS ─────────────────────────────────────────────
        $deals = [
            [
                'customer_id'      => $c1,
                'sales_id'         => $salesId,
                'manager_id'       => $managerId,
                'jenis_furnitur'   => 'Lemari Pakaian Sliding 3 Pintu',
                'item_pekerjaan'   => 'Engsel Blum soft-close, handle bar minimalis, kaca cermin tengah',
                'detail_pekerjaan' => 'Uk. 220x60x200 cm, HPL oak natural, finishing doff',
                'jenis_deal'       => 'DP',
                'nilai_proyek'     => 5500000,
                'dp_amount'        => 2000000,
                'status'           => 'produksi',
                'tgl_persetujuan'  => '2025-04-01',
                'garansi_hari'     => 30,
            ],
            [
                'customer_id'      => $c2,
                'sales_id'         => $salesId,
                'manager_id'       => $managerId,
                'jenis_furnitur'   => 'Kitchen Set Letter L Minimalis',
                'item_pekerjaan'   => 'Kompor tanam Rinnai 2 tungku, kabinet bawah+atas, backsplash keramik',
                'detail_pekerjaan' => 'Uk. 300x250x85 cm, HPL putih doff, granit hitam countertop',
                'jenis_deal'       => 'FP',
                'nilai_proyek'     => 18500000,
                'dp_amount'        => 18500000,
                'status'           => 'pemasangan',
                'tgl_persetujuan'  => '2025-04-03',
                'garansi_hari'     => 60,
            ],
            [
                'customer_id'      => $c3,
                'sales_id'         => $salesId,
                'manager_id'       => $managerId,
                'jenis_furnitur'   => 'Meja Kerja Custom & Rak Dinding',
                'item_pekerjaan'   => 'Laci samping dengan kunci, rak buku floating 3 baris',
                'detail_pekerjaan' => 'Uk. 160x70x75 cm, HPL oak, kaki besi hollow powder coat hitam',
                'jenis_deal'       => 'DP',
                'nilai_proyek'     => 4200000,
                'dp_amount'        => 1500000,
                'status'           => 'deal',
                'tgl_persetujuan'  => '2025-04-08',
                'garansi_hari'     => 30,
            ],
            [
                'customer_id'      => $c4,
                'sales_id'         => $salesId,
                'manager_id'       => $managerId,
                'jenis_furnitur'   => 'Wardrobe Built-in Walk-in Closet',
                'item_pekerjaan'   => 'Rak sepatu 30 pasang, laci baju, area hanger, cermin full body',
                'detail_pekerjaan' => 'Uk. 350x60x240 cm, HPL champagne, LED strip dalam',
                'jenis_deal'       => 'FP',
                'nilai_proyek'     => 22000000,
                'dp_amount'        => 22000000,
                'status'           => 'selesai',
                'tgl_persetujuan'  => '2025-03-15',
                'garansi_hari'     => 90,
                'garansi_end'      => '2025-06-13',
            ],
            [
                'customer_id'      => $c5,
                'sales_id'         => $salesId,
                'manager_id'       => $managerId,
                'jenis_furnitur'   => 'Rak TV & Backdrop Custom',
                'item_pekerjaan'   => 'Panel dinding kayu, rak kaca, ambient lighting LED',
                'detail_pekerjaan' => 'Uk. 400x30x220 cm, HPL wengee, profil MDF putih',
                'jenis_deal'       => 'DP',
                'nilai_proyek'     => 8800000,
                'dp_amount'        => 3000000,
                'status'           => 'produksi',
                'tgl_persetujuan'  => '2025-04-10',
                'garansi_hari'     => 30,
            ],
        ];
        foreach ($deals as $d) {
            DB::table('deals')->insertOrIgnore([...$d, 'created_at'=>now(), 'updated_at'=>now()]);
        }
        $d1 = DB::table('deals')->where('customer_id',$c1)->value('id');
        $d2 = DB::table('deals')->where('customer_id',$c2)->value('id');
        $d3 = DB::table('deals')->where('customer_id',$c3)->value('id');
        $d4 = DB::table('deals')->where('customer_id',$c4)->value('id');
        $d5 = DB::table('deals')->where('customer_id',$c5)->value('id');

        // ── RAB ───────────────────────────────────────────────
        if ($d1) DB::table('rabs')->insertOrIgnore(['deal_id'=>$d1,'cost_material'=>2200000,'cost_labor'=>1485000,'cost_finishing'=>990000,'cost_other'=>825000,'total'=>5500000,'status'=>'acc','created_at'=>now(),'updated_at'=>now()]);
        if ($d2) DB::table('rabs')->insertOrIgnore(['deal_id'=>$d2,'cost_material'=>7400000,'cost_labor'=>4995000,'cost_finishing'=>3330000,'cost_other'=>2775000,'total'=>18500000,'status'=>'acc','created_at'=>now(),'updated_at'=>now()]);

        // ── BAHAN ─────────────────────────────────────────────
        $bahans = [
            [$d1,'HPL Natural Oak','Motif kayu natural, coklat tua, matte tidak mengkilap',8,'lembar',185000,1480000,'Toko Sinar Jaya — Trespa No.T4','approved'],
            [$d1,'Engsel Blum 110° Soft-Close','Engsel soft close premium, tidak berisik',16,'pcs',45000,720000,'Toko Hardware KFB','diajukan'],
            [$d2,'HPL Putih Doff Arborite','Putih bersih tanpa motif, matte finish',12,'lembar',195000,2340000,'Toko Maju Jaya — minimal 10 lembar','dibeli'],
            [$d5,'HPL Wengee Taco','Coklat gelap motif kayu wengee',6,'lembar',190000,1140000,'Boleh alternatif Formica jika habis','diajukan'],
            [$d3,'Besi Hollow 4x4 Powder Coat','Kaki meja finishing hitam solid, tidak mudah karat',6,'batang',85000,510000,'Toko Besi Putra Jaya','approved'],
        ];
        foreach ($bahans as $b) {
            DB::table('bahan')->insertOrIgnore([
                'deal_id'=>$b[0],'nama_bahan'=>$b[1],'keinginan_customer'=>$b[2],
                'qty'=>$b[3],'satuan'=>$b[4],'harga_satuan'=>$b[5],'total_harga'=>$b[6],
                'catatan_toko'=>$b[7],'status'=>$b[8],
                'requested_by'=>$produksiId,
                'approved_by'=>in_array($b[8],['approved','dibeli'])?$adminId:null,
                'created_at'=>now(),'updated_at'=>now(),
            ]);
        }

        // ── JADWAL PEMASANGAN ─────────────────────────────────
        if ($d2) DB::table('jadwal_pemasangan')->insertOrIgnore([
            'deal_id'=>$d2,'tgl_pasang'=>'2025-04-20','jam_mulai'=>'08:00:00',
            'tim_pemasangan'=>'Pak Heru, Pak Dedi, Mas Rizki',
            'alamat_lokasi'=>'Jl. Padasuka No.12, Cibinong, Bogor 16914',
            'catatan_teknis'=>'Bawa kunci L ukuran 5 dan bor beton, akses lewat pintu samping',
            'status'=>'dijadwalkan','created_at'=>now(),'updated_at'=>now(),
        ]);
        if ($d4) DB::table('jadwal_pemasangan')->insertOrIgnore([
            'deal_id'=>$d4,'tgl_pasang'=>'2025-03-28','jam_mulai'=>'09:00:00',
            'tim_pemasangan'=>'Pak Agus, Mas Budi, Pak Heru',
            'alamat_lokasi'=>'Perum. Griya Indah Blok B-5, Sentul City, Bogor 16810',
            'catatan_teknis'=>'Lift tersedia, masuk lewat pintu belakang, parkir luas',
            'status'=>'selesai','tgl_selesai_aktual'=>'2025-03-28',
            'created_at'=>now(),'updated_at'=>now(),
        ]);

        // ── ABSENSI ───────────────────────────────────────────
        $absenDates = ['2025-04-17', '2025-04-16'];
        $absenData = [
            '2025-04-17' => [$salesId=>'hadir',$managerId=>'hadir',$adminId=>'hadir',$produksiId=>'absen'],
            '2025-04-16' => [$salesId=>'hadir',$managerId=>'hadir',$adminId=>'hadir',$produksiId=>'hadir'],
        ];
        foreach ($absenData as $tgl => $records) {
            foreach ($records as $uid => $status) {
                DB::table('absensi')->insertOrIgnore([
                    'user_id'=>$uid,'tanggal'=>$tgl,'status'=>$status,
                    'input_by'=>$adminId,'created_at'=>now(),'updated_at'=>now(),
                ]);
            }
        }

        // ── PETTY CASH ────────────────────────────────────────
        $pettys = [
            ['masuk','Lainnya',2000000,'Kas awal petty cash April 2025',null,'2025-04-01'],
            ['keluar','Operasional bengkel',420000,'Cat primer, amplas, lem kayu Rajawali',null,'2025-04-10'],
            ['keluar','Transport & pengiriman',180000,'Ongkir material HPL ke bengkel',null,'2025-04-12'],
            ['keluar','Makan tim',240000,'Makan siang tim lembur pemasangan',null,'2025-04-14'],
            ['keluar','ATK & supplies',85000,'Alat tulis dan nota pembelian',null,'2025-04-15'],
            ['masuk','Lainnya',500000,'Pengembalian uang lebih pembelian bahan',null,'2025-04-16'],
        ];
        foreach ($pettys as $p) {
            DB::table('petty_cash')->insertOrIgnore([
                'input_by'=>$adminId,'deal_id'=>$p[4],'type'=>$p[0],'kategori'=>$p[1],
                'jumlah'=>$p[2],'keterangan'=>$p[3],'tanggal'=>$p[5],
                'created_at'=>now(),'updated_at'=>now(),
            ]);
        }

        // ── MUTASI REKENING ───────────────────────────────────
        $mutasis = [
            [$d5,'masuk','dp_pesanan',3000000,'DP Hendra Gunawan — KFB-2025-005','2025-04-17'],
            [$d2,'masuk','pelunasan',18500000,'Pembayaran Full Rina Maharani — KFB-2025-002','2025-04-15'],
            [null,'keluar','gaji_tim',4200000,'Gaji tim produksi April (advance)','2025-04-13'],
            [null,'keluar','beli_material',4540000,'Beli material HPL & hardware batch 1','2025-04-11'],
            [$d3,'masuk','dp_pesanan',1500000,'DP Agus Widodo — KFB-2025-003','2025-04-08'],
            [$d4,'masuk','pelunasan',22000000,'Pelunasan Dewi Lestari — KFB-2025-004','2025-04-05'],
            [null,'keluar','beli_material',6200000,'Beli material walking closet batch 1','2025-04-03'],
            [$d1,'masuk','dp_pesanan',2000000,'DP Budi Santoso — KFB-2025-001','2025-04-01'],
        ];
        foreach ($mutasis as $m) {
            DB::table('mutasi_rekening')->insertOrIgnore([
                'deal_id'=>$m[0],'input_by'=>$adminId,'type'=>$m[1],'kategori'=>$m[2],
                'jumlah'=>$m[3],'keterangan'=>$m[4],'tanggal'=>$m[5],
                'created_at'=>now(),'updated_at'=>now(),
            ]);
        }

        $this->command->info('');
        $this->command->info('  ✓  KFB SIMT seeding selesai!');
        $this->command->info('');
        $this->command->info('  Login credentials:');
        $this->command->info('    owner@kfb.com    / password  → Owner');
        $this->command->info('    manager@kfb.com  / password  → Manager');
        $this->command->info('    sales@kfb.com    / password  → Sales');
        $this->command->info('    admin@kfb.com    / password  → Admin');
        $this->command->info('    produksi@kfb.com / password  → Tim Produksi');
        $this->command->info('');
    }
}
