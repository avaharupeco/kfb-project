<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('rabs', function (Blueprint $table) {
            $table->string('pekerjaan', 500)->nullable()->after('deal_id');
            $table->string('item_pekerjaan', 1000)->nullable()->after('pekerjaan');
            $table->text('detail_pekerjaan')->nullable()->after('item_pekerjaan');
            $table->unsignedInteger('waktu_pengerjaan')->default(0)->after('detail_pekerjaan'); // dalam hari
        });
    }

    public function down(): void
    {
        Schema::table('rabs', function (Blueprint $table) {
            $table->dropColumn(['pekerjaan', 'item_pekerjaan', 'detail_pekerjaan', 'waktu_pengerjaan']);
        });
    }
};
