<?php
// database/migrations/2024_01_01_000001_create_kfb_tables.php
// MySQL 8 — BIGINT auto-increment, tidak ada UUID, tidak ada PostgreSQL

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // ── USERS ────────────────────────────────────────────
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            $table->enum('role', ['owner','manager','sales','admin','produksi']);
            $table->boolean('is_active')->default(true);
            $table->rememberToken();
            $table->timestamps();
        });

        // ── CUSTOMERS (Master pelanggan) ──────────────────────
        Schema::create('customers', function (Blueprint $table) {
            $table->id();
            $table->string('kode', 20)->unique();                  // KFB-2025-001
            $table->string('name');
            $table->string('phone', 20)->unique();
            $table->string('email')->nullable();
            $table->text('address')->nullable();
            $table->enum('source', ['instagram','tiktok','website','whatsapp','referral','lainnya'])
                  ->default('whatsapp');
            $table->timestamps();
            $table->softDeletes();
        });

        // ── DEALS (Pesanan / Proyek) ──────────────────────────
        Schema::create('deals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained()->cascadeOnDelete();
            $table->foreignId('sales_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('manager_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('jenis_furnitur');                      // cth: Lemari Pakaian 3 Pintu
            $table->text('item_pekerjaan')->nullable();            // detail item
            $table->text('detail_pekerjaan')->nullable();          // spesifikasi teknis
            $table->enum('jenis_deal', ['FP', 'DP']);              // Full Payment / Down Payment
            $table->unsignedBigInteger('nilai_proyek')->default(0);
            $table->unsignedBigInteger('dp_amount')->default(0);
            $table->enum('status', ['deal','produksi','pemasangan','selesai'])->default('deal');
            $table->date('tgl_persetujuan');
            $table->integer('garansi_hari')->default(30);          // masa garansi dalam hari
            $table->date('garansi_end')->nullable();               // auto-hitung setelah selesai
            $table->text('catatan')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        // ── RAB (Rencana Anggaran Biaya) ─────────────────────
        Schema::create('rabs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('deal_id')->unique()->constrained()->cascadeOnDelete();
            $table->unsignedBigInteger('cost_material')->default(0);
            $table->unsignedBigInteger('cost_labor')->default(0);
            $table->unsignedBigInteger('cost_finishing')->default(0);
            $table->unsignedBigInteger('cost_other')->default(0);
            $table->unsignedBigInteger('total')->default(0);       // auto-sum
            $table->enum('status', ['draft','terkirim','acc'])->default('draft');
            $table->timestamps();
        });

        // ── BAHAN (Pengajuan Kebutuhan Bahan) ─────────────────
        Schema::create('bahan', function (Blueprint $table) {
            $table->id();
            $table->foreignId('deal_id')->constrained()->cascadeOnDelete();
            $table->foreignId('requested_by')->constrained('users');         // tim produksi
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete(); // admin/owner
            $table->string('nama_bahan');
            $table->text('keinginan_customer')->nullable();                  // bahan yg diinginkan cust
            $table->decimal('qty', 10, 2);
            $table->string('satuan', 20)->default('pcs');
            $table->unsignedBigInteger('harga_satuan')->default(0);
            $table->unsignedBigInteger('total_harga')->default(0);          // qty * harga_satuan
            $table->string('catatan_toko')->nullable();                      // toko tujuan, merk, dll
            $table->enum('status', ['diajukan','approved','dibeli','ditolak'])->default('diajukan');
            $table->string('struk_url')->nullable();                         // foto struk pembelian
            $table->timestamps();
        });

        // ── JADWAL PEMASANGAN ─────────────────────────────────
        Schema::create('jadwal_pemasangan', function (Blueprint $table) {
            $table->id();
            $table->foreignId('deal_id')->constrained()->cascadeOnDelete();
            $table->date('tgl_pasang');
            $table->time('jam_mulai')->default('08:00:00');
            $table->string('tim_pemasangan');                               // nama-nama anggota tim
            $table->text('alamat_lokasi');
            $table->text('catatan_teknis')->nullable();
            $table->enum('status', ['dijadwalkan','berjalan','selesai'])->default('dijadwalkan');
            $table->date('tgl_selesai_aktual')->nullable();
            $table->timestamps();
        });

        // ── ABSENSI ───────────────────────────────────────────
        Schema::create('absensi', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->date('tanggal');
            $table->enum('status', ['hadir','absen','izin','sakit'])->default('hadir');
            $table->text('keterangan')->nullable();
            $table->foreignId('input_by')->constrained('users');            // admin yang input
            $table->timestamps();
            $table->unique(['user_id', 'tanggal']);                         // 1 absen per user per hari
        });

        // ── PETTY CASH ────────────────────────────────────────
        Schema::create('petty_cash', function (Blueprint $table) {
            $table->id();
            $table->foreignId('input_by')->constrained('users');
            $table->foreignId('deal_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('type', ['masuk','keluar']);
            $table->string('kategori', 60);
            $table->unsignedBigInteger('jumlah');
            $table->text('keterangan')->nullable();
            $table->date('tanggal');
            $table->timestamps();
            $table->index(['type', 'tanggal']);
        });

        // ── MUTASI REKENING ───────────────────────────────────
        Schema::create('mutasi_rekening', function (Blueprint $table) {
            $table->id();
            $table->foreignId('deal_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('input_by')->constrained('users');
            $table->enum('type', ['masuk','keluar']);
            $table->string('kategori', 60)->default('transfer');
            $table->unsignedBigInteger('jumlah');
            $table->text('keterangan')->nullable();
            $table->string('no_referensi')->nullable();                     // no. bukti transfer
            $table->date('tanggal');
            $table->timestamps();
            $table->index(['type', 'tanggal']);
        });

        // ── PERSONAL ACCESS TOKENS (Sanctum) ─────────────────
        Schema::create('personal_access_tokens', function (Blueprint $table) {
            $table->id();
            $table->morphs('tokenable');
            $table->string('name');
            $table->string('token', 64)->unique();
            $table->text('abilities')->nullable();
            $table->timestamp('last_used_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('personal_access_tokens');
        Schema::dropIfExists('mutasi_rekening');
        Schema::dropIfExists('petty_cash');
        Schema::dropIfExists('absensi');
        Schema::dropIfExists('jadwal_pemasangan');
        Schema::dropIfExists('bahan');
        Schema::dropIfExists('rabs');
        Schema::dropIfExists('deals');
        Schema::dropIfExists('customers');
        Schema::dropIfExists('users');
    }
};
