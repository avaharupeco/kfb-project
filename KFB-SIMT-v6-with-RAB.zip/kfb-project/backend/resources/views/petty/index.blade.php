@extends('layouts.app')
@section('title','Petty Cash')
@section('page-title','Petty Cash Harian')
@section('topbar-actions')
  <button onclick="document.getElementById('modal-petty').style.display='flex'" class="btn btn-primary btn-sm">+ Catat Transaksi</button>
@endsection
@section('content')
<div class="metric-row col-3">
  <div class="metric"><div class="metric-label">Total Pemasukan</div><div class="metric-value ok">Rp {{ number_format($masuk) }}</div></div>
  <div class="metric"><div class="metric-label">Total Pengeluaran</div><div class="metric-value err">Rp {{ number_format($keluar) }}</div></div>
  <div class="metric"><div class="metric-label">Saldo Petty Cash</div><div class="metric-value wood">Rp {{ number_format($saldo) }}</div></div>
</div>
<div class="card">
  <div class="card-header"><div class="card-title">Rincian Petty Cash</div></div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Tanggal</th><th>Keterangan</th><th>Kategori</th><th>Input Oleh</th><th>Jenis</th><th style="text-align:right">Jumlah</th></tr></thead>
      <tbody>
        @forelse($petty as $p)
        <tr>
          <td style="font-size:11px">{{ $p->tanggal->format('d M Y') }}</td>
          <td class="td-main">{{ $p->keterangan }}</td>
          <td style="font-size:11px;color:var(--muted)">{{ $p->kategori }}</td>
          <td style="font-size:11px">{{ $p->inputBy->name }}</td>
          <td><span class="badge badge-{{ $p->type }}">{{ $p->type==='masuk'?'Masuk':'Keluar' }}</span></td>
          <td style="text-align:right;font-weight:700;color:{{ $p->type==='masuk'?'var(--ok)':'var(--err)' }}">
            {{ $p->type==='masuk'?'+':'-' }} Rp {{ number_format($p->jumlah) }}
          </td>
        </tr>
        @empty
        <tr><td colspan="6" class="empty-state">Belum ada transaksi petty cash</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  {{ $petty->links() }}
</div>
@endsection
@section('modals')
<div id="modal-petty" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:500;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:14px;padding:26px;width:480px;max-width:96vw;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
      <h2 style="font-size:15px;font-weight:700">Catat Petty Cash</h2>
      <button onclick="document.getElementById('modal-petty').style.display='none'" style="background:var(--bg);border:none;width:28px;height:28px;border-radius:50%;cursor:pointer;font-size:14px">✕</button>
    </div>
    <form action="{{ url('/petty') }}" method="POST">
      @csrf
      <div class="form-row">
        <div class="form-group"><label class="form-label">Jenis</label><select class="form-control" name="type"><option value="keluar">Pengeluaran</option><option value="masuk">Pemasukan</option></select></div>
        <div class="form-group"><label class="form-label">Jumlah (Rp)</label><input class="form-control" type="number" name="jumlah" min="1" required placeholder="0"></div>
      </div>
      <div class="form-group"><label class="form-label">Kategori</label>
        <select class="form-control" name="kategori">
          <option>Operasional bengkel</option><option>Beli bahan minor</option><option>Transport & pengiriman</option><option>Makan tim</option><option>ATK & supplies</option><option>Kebersihan</option><option>Lainnya</option>
        </select>
      </div>
      <div class="form-group"><label class="form-label">Keterangan</label><input class="form-control" name="keterangan" placeholder="Detail pengeluaran..."></div>
      <div class="form-group"><label class="form-label">Tanggal</label><input class="form-control" type="date" name="tanggal" value="{{ date('Y-m-d') }}" required></div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:11px">Simpan Transaksi</button>
    </form>
  </div>
</div>
@endsection
