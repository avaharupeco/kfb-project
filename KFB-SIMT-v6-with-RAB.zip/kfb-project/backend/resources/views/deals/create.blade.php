@extends('layouts.app')
@section('title','Input Deal Baru')
@section('page-title','Input Deal Customer Baru')
@section('content')
<div style="max-width:680px">
  <div class="card">
    <div class="card-header"><div class="card-title">Form Deal Customer</div><div class="card-sub">Isi setelah customer setuju dan deal dikonfirmasi</div></div>
    <form action="{{ url('/deals') }}" method="POST" novalidate>
      @csrf
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Customer</label>
          <select class="form-control" name="customer_id" required>
            <option value="">-- Pilih Customer --</option>
            @foreach($customers as $c)<option value="{{ $c->id }}" {{ old('customer_id')==$c->id?'selected':'' }}>{{ $c->name }} ({{ $c->kode }})</option>@endforeach
          </select>
        </div>
        <div class="form-group" style="display:flex;align-items:flex-end">
          <a href="{{ url('/customers/create') }}" class="btn btn-secondary btn-sm">+ Customer Baru</a>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Jenis Furnitur</label>
        <input class="form-control" type="text" name="jenis_furnitur" value="{{ old('jenis_furnitur') }}" placeholder="cth: Lemari Pakaian Sliding 3 Pintu, Kitchen Set Letter L" required>
      </div>
      <div class="form-group">
        <label class="form-label">Item Pekerjaan</label>
        <textarea class="form-control" name="item_pekerjaan" rows="2" placeholder="Engsel Blum soft-close, handle minimalis, kaca cermin tengah...">{{ old('item_pekerjaan') }}</textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Detail Pekerjaan (Spesifikasi Teknis)</label>
        <textarea class="form-control" name="detail_pekerjaan" rows="2" placeholder="Ukuran, material, finishing, warna, kode HPL...">{{ old('detail_pekerjaan') }}</textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Nilai Proyek (Rp)</label>
          <input class="form-control" type="number" name="nilai_proyek" value="{{ old('nilai_proyek',0) }}" min="0" required>
        </div>
        <div class="form-group">
          <label class="form-label">Jenis Deal</label>
          <select class="form-control" name="jenis_deal" required>
            <option value="FP" {{ old('jenis_deal')==='FP'?'selected':'' }}>FP — Full Payment (Bayar Penuh)</option>
            <option value="DP" {{ old('jenis_deal')==='DP'?'selected':'' }}>DP — Down Payment (Uang Muka)</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Jumlah DP (Rp) <span style="color:var(--hint);font-weight:400">(untuk jenis DP, kosongkan jika FP)</span></label>
        <input class="form-control" type="number" name="dp_amount" value="{{ old('dp_amount',0) }}" min="0">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Manager</label>
          <select class="form-control" name="manager_id" required>
            @foreach($managers as $m)<option value="{{ $m->id }}" {{ old('manager_id')==$m->id?'selected':'' }}>{{ $m->name }}</option>@endforeach
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Tanggal Persetujuan</label>
          <input class="form-control" type="date" name="tgl_persetujuan" value="{{ old('tgl_persetujuan', date('Y-m-d')) }}" required>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Masa Garansi</label>
        <select class="form-control" name="garansi_hari">
          <option value="30" {{ old('garansi_hari')==30?'selected':'' }}>30 hari</option>
          <option value="60" {{ old('garansi_hari')==60?'selected':'' }}>60 hari</option>
          <option value="90" {{ old('garansi_hari')==90?'selected':'' }}>90 hari</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Catatan Tambahan</label>
        <textarea class="form-control" name="catatan" rows="2" placeholder="Permintaan khusus, akses lokasi, dll">{{ old('catatan') }}</textarea>
      </div>
      <div style="display:flex;gap:8px">
        <button type="submit" class="btn btn-primary">Simpan Data Deal</button>
        <a href="{{ url('/deals') }}" class="btn btn-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>
@endsection
