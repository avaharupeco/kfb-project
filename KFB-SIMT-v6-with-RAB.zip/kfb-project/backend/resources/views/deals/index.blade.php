@extends('layouts.app')
@section('title','Data Customer & Deal')
@section('page-title','Data Customer & Deal')
@section('topbar-actions')
  @can_role(['sales','admin','owner'])
    <a href="{{ url('/deals/create') }}" class="btn btn-primary btn-sm">+ Input Deal Baru</a>
  @endcan_role
@endsection
@section('content')
@php $stClass=['deal'=>'badge-deal','produksi'=>'badge-produksi','pemasangan'=>'badge-pemasangan','selesai'=>'badge-selesai']; $stLabel=['deal'=>'Deal','produksi'=>'Produksi','pemasangan'=>'Pemasangan','selesai'=>'Selesai']; @endphp
<div class="filter-bar">
  <form method="GET" action="{{ url('/deals') }}" style="display:flex;gap:8px;flex:1;flex-wrap:wrap">
    <input class="search-input" name="search" value="{{ request('search') }}" placeholder="Cari nama / kode...">
    <a href="{{ url('/deals') }}" class="chip {{ !request('status') ? 'active' : '' }}">Semua</a>
    @foreach(['deal','produksi','pemasangan','selesai'] as $s)
      <a href="{{ url('/deals?status='.$s.'&search='.request('search')) }}" class="chip {{ request('status')===$s ? 'active' : '' }}">{{ $stLabel[$s] }}</a>
    @endforeach
  </form>
</div>
<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Kode</th><th>Customer</th><th>Jenis Furnitur</th><th>Sales</th><th>Manager</th><th>Nilai</th><th>DP</th><th>Sisa</th><th>Deal</th><th>Garansi</th><th>Status</th><th>Tgl</th><th>Aksi</th></tr></thead>
      <tbody>
        @forelse($deals as $d)
        <tr>
          <td style="font-size:10px;color:var(--muted);font-weight:600">{{ $d->customer->kode }}</td>
          <td><div class="td-main">{{ $d->customer->name }}</div><div class="td-sub">{{ $d->customer->phone }}</div></td>
          <td style="font-size:11px;max-width:150px">{{ $d->jenis_furnitur }}</td>
          <td style="font-size:11px">{{ $d->sales?->name ?? '-' }}</td>
          <td style="font-size:11px">{{ $d->manager?->name ?? '-' }}</td>
          <td><strong>Rp {{ number_format($d->nilai_proyek) }}</strong></td>
          <td style="color:var(--ok);font-size:11px">Rp {{ number_format($d->dp_amount) }}</td>
          <td style="color:{{ $d->sisa()>0?'var(--err)':'var(--ok)' }};font-size:11px">Rp {{ number_format($d->sisa()) }}</td>
          <td><span class="badge {{ $d->jenis_deal==='FP'?'badge-fp':'badge-dp' }}">{{ $d->jenis_deal }}</span></td>
          <td style="font-size:11px">{{ $d->garansi_hari }} hr</td>
          <td><span class="badge {{ $stClass[$d->status] }}">{{ $stLabel[$d->status] }}</span></td>
          <td style="font-size:11px">{{ $d->tgl_persetujuan->format('d/m/Y') }}</td>
          <td><a href="{{ url('/deals/'.$d->id) }}" class="btn btn-secondary btn-xs">Detail</a></td>
        </tr>
        @empty
        <tr><td colspan="13" class="empty-state">Belum ada deal</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  <div>{{ $deals->withQueryString()->links() }}</div>
</div>
@endsection
