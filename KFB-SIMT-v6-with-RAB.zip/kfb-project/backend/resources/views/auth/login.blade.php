<!DOCTYPE html>
<html lang="id" data-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login — KFB SIMT</title>
  <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">
  <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('favicon-32x32.png') }}">
  <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('favicon-16x16.png') }}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="{{ asset('css/app.css') }}">
  <style>
    :root{--card-right:#fff;--title:#1C1007;--subtitle:#A8896C;--demo-bg:#FFFBEB;--demo-border:rgba(124,61,18,.15);--demo-title:#78614E;--demo-email:#7C3D12;--demo-role:#78614E;--input-bg:#fff;--input-border:#e5d5c5;--input-color:#1C1007;--label:#6B4F3A;--link:#7C3D12;}
    [data-theme="dark"]{--card-right:#1F2937;--title:#F9FAFB;--subtitle:#9CA3AF;--demo-bg:#1a1200;--demo-border:rgba(180,83,9,.3);--demo-title:#9CA3AF;--demo-email:#F59E0B;--demo-role:#9CA3AF;--input-bg:#111827;--input-border:#374151;--input-color:#F9FAFB;--label:#9CA3AF;--link:#F59E0B;}
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
    html,body{min-height:100vh;font-family:'Inter',sans-serif;}
    body{display:flex;align-items:center;justify-content:center;transition:background .3s;}
    [data-theme="light"] body{background:linear-gradient(135deg,#1a0f08 0%,#2d1810 50%,#1a0f08 100%);}
    [data-theme="dark"] body{background:linear-gradient(135deg,#060912 0%,#111827 50%,#060912 100%);}
    .theme-toggle{position:fixed;top:16px;right:16px;width:36px;height:36px;border-radius:50%;border:1.5px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:16px;transition:all .2s;z-index:100;}
    .theme-toggle:hover{background:rgba(255,255,255,.18);}
    .login-card{display:flex;width:880px;max-width:97vw;border-radius:18px;overflow:hidden;box-shadow:0 24px 80px rgba(0,0,0,.5);}
    .login-left{width:300px;background:rgba(255,255,255,.04);border-right:1px solid rgba(255,255,255,.08);padding:40px 32px;display:flex;flex-direction:column;flex-shrink:0;}
    .login-logo{width:42px;height:42px;background:#7C3D12;border-radius:10px;display:flex;align-items:center;justify-content:center;margin-bottom:18px;}
    .login-brand{color:#FFF8F0;font-size:18px;font-weight:700;}
    .login-sub{color:rgba(255,248,240,.30);font-size:9px;letter-spacing:2px;margin-top:2px;}
    .login-desc{color:rgba(255,248,240,.45);font-size:11.5px;line-height:1.75;margin-top:18px;}
    .role-card{display:flex;align-items:flex-start;gap:10px;padding:8px 10px;border-radius:8px;margin-bottom:3px;cursor:pointer;border:none;width:100%;text-align:left;background:none;font-family:inherit;transition:background .15s;}
    .role-card:hover{background:rgba(255,255,255,.07);}
    .role-dot{width:7px;height:7px;border-radius:50%;margin-top:4px;flex-shrink:0;}
    .role-name{color:rgba(255,248,240,.80);font-size:12px;font-weight:500;}
    .role-desc{color:rgba(255,248,240,.35);font-size:10px;margin-top:1px;line-height:1.4;}
    .login-right{flex:1;background:var(--card-right);padding:40px 42px;transition:background .3s;}
    .login-title{font-size:22px;font-weight:700;color:var(--title);margin-bottom:4px;transition:color .3s;}
    .login-subtitle{font-size:12.5px;color:var(--subtitle);margin-bottom:26px;transition:color .3s;}
    .form-group{margin-bottom:16px;}
    .form-label{display:block;font-size:12px;font-weight:600;color:var(--label);margin-bottom:6px;transition:color .3s;}
    .form-control{width:100%;padding:10px 12px;font-size:13px;font-family:'Inter',sans-serif;background:var(--input-bg);color:var(--input-color);border:1.5px solid var(--input-border);border-radius:8px;outline:none;transition:all .2s;}
    .form-control:focus{border-color:#7C3D12;box-shadow:0 0 0 3px rgba(124,61,18,.12);}
    [data-theme="dark"] .form-control:focus{border-color:#F59E0B;box-shadow:0 0 0 3px rgba(245,158,11,.15);}
    .btn-primary{width:100%;padding:11px;font-size:13px;font-weight:600;font-family:'Inter',sans-serif;background:#7C3D12;color:#fff;border:none;border-radius:8px;cursor:pointer;transition:background .2s;margin-top:4px;}
    .btn-primary:hover{background:#6B3410;}
    [data-theme="dark"] .btn-primary{background:#D97706;}
    [data-theme="dark"] .btn-primary:hover{background:#B45309;}
    .register-link{text-align:center;margin-top:14px;font-size:11.5px;color:var(--subtitle);}
    .register-link a{color:var(--link);font-weight:600;text-decoration:none;}
    .register-link a:hover{text-decoration:underline;}
    .demo-box{background:var(--demo-bg);border:1px solid var(--demo-border);border-radius:7px;padding:12px 14px;margin-top:18px;transition:all .3s;}
    .demo-title{font-size:9px;font-weight:700;color:var(--demo-title);letter-spacing:.8px;margin-bottom:8px;text-transform:uppercase;}
    .demo-row{display:flex;justify-content:space-between;padding:4px 0;font-size:11px;border-bottom:1px solid var(--demo-border);}
    .demo-row:last-child{border:none;}
    .demo-email{color:var(--demo-email);font-weight:600;}
    .demo-role{color:var(--demo-role);}
    .alert{padding:10px 14px;border-radius:8px;font-size:12.5px;margin-bottom:16px;}
    .alert-error{background:#FEF2F2;color:#B91C1C;border:1px solid #FECACA;}
    [data-theme="dark"] .alert-error{background:#1f0a0a;color:#FCA5A5;border-color:#7f1d1d;}
  </style>
</head>
<body>
<button class="theme-toggle" onclick="toggleTheme()" id="themeBtn">🌙</button>
<div class="login-card">
  <div class="login-left">
    <div>
      <div class="login-logo">
        <svg width="20" height="20" viewBox="0 0 19 19" fill="none"><rect x="1.5" y="10" width="16" height="5" rx="1.8" fill="#FFF8F0" opacity=".9"/><rect x="3" y="3.5" width="13" height="7.5" rx="1.8" fill="#FFF8F0" opacity=".65"/><rect x="3" y="15" width="2.2" height="2.8" rx=".9" fill="#FFF8F0" opacity=".5"/><rect x="13.8" y="15" width="2.2" height="2.8" rx=".9" fill="#FFF8F0" opacity=".5"/></svg>
      </div>
      <div class="login-brand">Kurnia Furniture Bogor</div>
      <div class="login-sub">SIMT · SISTEM INTERNAL v2.0</div>
      <div class="login-desc">Setiap divisi memiliki akses tersendiri yang disesuaikan dengan peran dan tanggung jawabnya.</div>
      <div style="margin-top:18px">
        <button class="role-card" onclick="isi('owner@kfb.com')"><div class="role-dot" style="background:#F59E0B"></div><div><div class="role-name">Owner</div><div class="role-desc">Pantau omzet, laporan & pengeluaran</div></div></button>
        <button class="role-card" onclick="isi('manager@kfb.com')"><div class="role-dot" style="background:#8B5CF6"></div><div><div class="role-name">Manager</div><div class="role-desc">Hasil proyek, RAB, laporan gaji</div></div></button>
        <button class="role-card" onclick="isi('sales@kfb.com')"><div class="role-dot" style="background:#10B981"></div><div><div class="role-name">Sales</div><div class="role-desc">Input customer, deal, garansi</div></div></button>
        <button class="role-card" onclick="isi('admin@kfb.com')"><div class="role-dot" style="background:#3B82F6"></div><div><div class="role-name">Admin</div><div class="role-desc">Database, absensi, petty cash, mutasi</div></div></button>
        <button class="role-card" onclick="isi('produksi@kfb.com')"><div class="role-dot" style="background:#EF4444"></div><div><div class="role-name">Tim Produksi</div><div class="role-desc">Bahan, jadwal pemasangan, kanban</div></div></button>
      </div>
    </div>
    <div style="color:rgba(255,248,240,.15);font-size:10px;margin-top:14px">© 2025 KFB · Ciampea, Bogor</div>
  </div>
  <div class="login-right">
    <div class="login-title">Selamat Datang</div>
    <div class="login-subtitle">Masuk sesuai divisi Anda untuk mengakses fitur yang tersedia</div>
    @if($errors->any())
      <div class="alert alert-error">{{ $errors->first() }}</div>
    @endif
    <form action="{{ url('/login') }}" method="POST" novalidate>
      @csrf
      <div class="form-group">
        <label class="form-label" for="email">Alamat Email</label>
        <input class="form-control" type="email" id="email" name="email" value="{{ old('email') }}" placeholder="divisi@kfb.com" autofocus autocomplete="email" required>
      </div>
      <div class="form-group">
        <label class="form-label" for="password">Password</label>
        <input class="form-control" type="password" id="password" name="password" placeholder="••••••••" autocomplete="current-password" required>
      </div>
      <button type="submit" class="btn-primary">Masuk ke Sistem →</button>
    </form>
    <div class="register-link">
      Belum punya akun? <a href="{{ url('/register') }}">Daftar sekarang</a>
    </div>
    <div class="demo-box">
      <div class="demo-title">Akun Demo — Password semua: <strong>password</strong></div>
      <div class="demo-row"><span class="demo-email">owner@kfb.com</span><span class="demo-role">Owner</span></div>
      <div class="demo-row"><span class="demo-email">manager@kfb.com</span><span class="demo-role">Manager</span></div>
      <div class="demo-row"><span class="demo-email">sales@kfb.com</span><span class="demo-role">Sales</span></div>
      <div class="demo-row"><span class="demo-email">admin@kfb.com</span><span class="demo-role">Admin</span></div>
      <div class="demo-row"><span class="demo-email">produksi@kfb.com</span><span class="demo-role">Tim Produksi</span></div>
    </div>
  </div>
</div>
<script>
  function getTheme(){return localStorage.getItem('kfb-theme')||'light';}
  function applyTheme(t){document.documentElement.setAttribute('data-theme',t);document.getElementById('themeBtn').textContent=t==='dark'?'☀️':'🌙';localStorage.setItem('kfb-theme',t);}
  function toggleTheme(){applyTheme(getTheme()==='dark'?'light':'dark');}
  applyTheme(getTheme());
  function isi(email){document.getElementById('email').value=email;document.getElementById('password').value='password';document.getElementById('password').focus();}
</script>
</body>
</html>
