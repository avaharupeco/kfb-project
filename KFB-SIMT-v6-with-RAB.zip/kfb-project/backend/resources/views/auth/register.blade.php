<!DOCTYPE html>
<html lang="id" data-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrasi — KFB SIMT</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="{{ asset('css/app.css') }}">
  <style>
    :root{--card-right:#fff;--title:#1C1007;--subtitle:#A8896C;--input-bg:#fff;--input-border:#e5d5c5;--input-color:#1C1007;--label:#6B4F3A;--link:#7C3D12;}
    [data-theme="dark"]{--card-right:#1F2937;--title:#F9FAFB;--subtitle:#9CA3AF;--input-bg:#111827;--input-border:#374151;--input-color:#F9FAFB;--label:#9CA3AF;--link:#F59E0B;}
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
    html,body{min-height:100vh;font-family:'Inter',sans-serif;}
    body{display:flex;align-items:center;justify-content:center;transition:background .3s;padding:20px 0;}
    [data-theme="light"] body{background:linear-gradient(135deg,#1a0f08 0%,#2d1810 50%,#1a0f08 100%);}
    [data-theme="dark"] body{background:linear-gradient(135deg,#060912 0%,#111827 50%,#060912 100%);}
    .theme-toggle{position:fixed;top:16px;right:16px;width:36px;height:36px;border-radius:50%;border:1.5px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:16px;transition:all .2s;z-index:100;}
    .theme-toggle:hover{background:rgba(255,255,255,.18);}
    .reg-card{display:flex;width:820px;max-width:97vw;border-radius:18px;overflow:hidden;box-shadow:0 24px 80px rgba(0,0,0,.5);}
    .reg-left{width:260px;background:rgba(255,255,255,.04);border-right:1px solid rgba(255,255,255,.08);padding:36px 24px;display:flex;flex-direction:column;flex-shrink:0;}
    .reg-logo{width:40px;height:40px;background:#7C3D12;border-radius:10px;display:flex;align-items:center;justify-content:center;margin-bottom:14px;}
    .reg-brand{color:#FFF8F0;font-size:16px;font-weight:700;}
    .reg-sub{color:rgba(255,248,240,.30);font-size:9px;letter-spacing:2px;margin-top:2px;}
    .reg-desc{color:rgba(255,248,240,.45);font-size:11px;line-height:1.7;margin-top:14px;}
    .role-opt{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;margin-bottom:4px;cursor:pointer;border:1.5px solid transparent;width:100%;text-align:left;background:none;font-family:inherit;transition:all .15s;}
    .role-opt:hover{background:rgba(255,255,255,.07);}
    .role-opt.active{border-color:rgba(255,255,255,.25);background:rgba(255,255,255,.10);}
    .role-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}
    .role-name{color:rgba(255,248,240,.85);font-size:12px;font-weight:600;}
    .role-desc{color:rgba(255,248,240,.35);font-size:10px;margin-top:1px;line-height:1.4;}
    .reg-right{flex:1;background:var(--card-right);padding:36px;overflow-y:auto;max-height:92vh;transition:background .3s;}
    .back-link{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--subtitle);text-decoration:none;margin-bottom:20px;transition:color .2s;}
    .back-link:hover{color:var(--link);}
    .reg-title{font-size:20px;font-weight:700;color:var(--title);margin-bottom:3px;transition:color .3s;}
    .reg-subtitle{font-size:12px;color:var(--subtitle);margin-bottom:22px;transition:color .3s;}
    .form-group{margin-bottom:14px;}
    .form-label{display:block;font-size:12px;font-weight:600;color:var(--label);margin-bottom:5px;transition:color .3s;}
    .form-control{width:100%;padding:9px 12px;font-size:13px;font-family:'Inter',sans-serif;background:var(--input-bg);color:var(--input-color);border:1.5px solid var(--input-border);border-radius:8px;outline:none;transition:all .2s;}
    .form-control:focus{border-color:#7C3D12;box-shadow:0 0 0 3px rgba(124,61,18,.12);}
    [data-theme="dark"] .form-control:focus{border-color:#F59E0B;box-shadow:0 0 0 3px rgba(245,158,11,.15);}
    .selected-role{display:none;padding:8px 12px;border-radius:8px;font-size:12px;font-weight:600;margin-bottom:16px;border:1.5px solid;}
    .btn-primary{width:100%;padding:11px;font-size:13px;font-weight:600;font-family:'Inter',sans-serif;background:#7C3D12;color:#fff;border:none;border-radius:8px;cursor:pointer;transition:background .2s;margin-top:4px;}
    .btn-primary:hover{background:#6B3410;}
    [data-theme="dark"] .btn-primary{background:#D97706;}
    [data-theme="dark"] .btn-primary:hover{background:#B45309;}
    .login-link{text-align:center;margin-top:14px;font-size:11.5px;color:var(--subtitle);}
    .login-link a{color:var(--link);font-weight:600;text-decoration:none;}
    .login-link a:hover{text-decoration:underline;}
    .alert{padding:10px 14px;border-radius:8px;font-size:12.5px;margin-bottom:16px;}
    .alert-error{background:#FEF2F2;color:#B91C1C;border:1px solid #FECACA;}
    [data-theme="dark"] .alert-error{background:#1f0a0a;color:#FCA5A5;border-color:#7f1d1d;}
    .alert-success{background:#F0FDF4;color:#166534;border:1px solid #BBF7D0;}
  </style>
</head>
<body>
<button class="theme-toggle" onclick="toggleTheme()" id="themeBtn">🌙</button>
<div class="reg-card">
  {{-- Kiri: pilih role --}}
  <div class="reg-left">
    <div>
      <div class="reg-logo">
        <svg width="20" height="20" viewBox="0 0 19 19" fill="none"><rect x="1.5" y="10" width="16" height="5" rx="1.8" fill="#FFF8F0" opacity=".9"/><rect x="3" y="3.5" width="13" height="7.5" rx="1.8" fill="#FFF8F0" opacity=".65"/><rect x="3" y="15" width="2.2" height="2.8" rx=".9" fill="#FFF8F0" opacity=".5"/><rect x="13.8" y="15" width="2.2" height="2.8" rx=".9" fill="#FFF8F0" opacity=".5"/></svg>
      </div>
      <div class="reg-brand">Kurnia Furniture Bogor</div>
      <div class="reg-sub">SIMT · SISTEM INTERNAL v2.0</div>
      <div class="reg-desc">Pilih divisi Anda terlebih dahulu, lalu isi data untuk membuat akun.</div>
      <div style="margin-top:18px;font-size:10px;color:rgba(255,248,240,.3);letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;">Pilih Role</div>
      <button class="role-opt" onclick="pilihRole('owner','#F59E0B','Owner','Pantau omzet & laporan')" id="btn-owner">
        <div class="role-dot" style="background:#F59E0B"></div><div><div class="role-name">Owner</div><div class="role-desc">Pantau omzet & laporan</div></div>
      </button>
      <button class="role-opt" onclick="pilihRole('manager','#8B5CF6','Manager','Proyek, RAB, laporan gaji')" id="btn-manager">
        <div class="role-dot" style="background:#8B5CF6"></div><div><div class="role-name">Manager</div><div class="role-desc">Proyek, RAB, laporan gaji</div></div>
      </button>
      <button class="role-opt" onclick="pilihRole('sales','#10B981','Sales','Input customer & deal')" id="btn-sales">
        <div class="role-dot" style="background:#10B981"></div><div><div class="role-name">Sales</div><div class="role-desc">Input customer & deal</div></div>
      </button>
      <button class="role-opt" onclick="pilihRole('admin','#3B82F6','Admin','Database & operasional')" id="btn-admin">
        <div class="role-dot" style="background:#3B82F6"></div><div><div class="role-name">Admin</div><div class="role-desc">Database & operasional</div></div>
      </button>
      <button class="role-opt" onclick="pilihRole('produksi','#EF4444','Tim Produksi','Bahan & jadwal')" id="btn-produksi">
        <div class="role-dot" style="background:#EF4444"></div><div><div class="role-name">Tim Produksi</div><div class="role-desc">Bahan & jadwal</div></div>
      </button>
    </div>
    <div style="color:rgba(255,248,240,.15);font-size:10px;margin-top:14px">© 2025 KFB · Ciampea, Bogor</div>
  </div>

  {{-- Kanan: form --}}
  <div class="reg-right">
    <a href="{{ url('/login') }}" class="back-link">
      ← Kembali ke Login
    </a>
    <div class="reg-title">Buat Akun Baru</div>
    <div class="reg-subtitle">Isi data di bawah untuk mendaftar ke sistem KFB SIMT</div>

    @if($errors->any())
      <div class="alert alert-error">{{ $errors->first() }}</div>
    @endif
    @if(session('success'))
      <div class="alert alert-success">✓ {{ session('success') }}</div>
    @endif

    <div class="selected-role" id="selectedRoleBox">
      Role dipilih: <span id="selectedRoleName">-</span>
    </div>

    <form action="{{ url('/register') }}" method="POST" novalidate>
      @csrf
      <input type="hidden" name="role" id="roleInput" value="{{ old('role') }}">
      <div class="form-group">
        <label class="form-label">Nama Lengkap</label>
        <input class="form-control" type="text" name="name" value="{{ old('name') }}" placeholder="Nama sesuai divisi" required autofocus>
      </div>
      <div class="form-group">
        <label class="form-label">Alamat Email</label>
        <input class="form-control" type="email" name="email" value="{{ old('email') }}" placeholder="divisi@kfb.com" required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input class="form-control" type="password" name="password" placeholder="Minimal 8 karakter" required>
      </div>
      <div class="form-group">
        <label class="form-label">Konfirmasi Password</label>
        <input class="form-control" type="password" name="password_confirmation" placeholder="Ulangi password" required>
      </div>
      <button type="submit" class="btn-primary">Daftar ke Sistem →</button>
    </form>

    <div class="login-link">
      Sudah punya akun? <a href="{{ url('/login') }}">Masuk sekarang</a>
    </div>
  </div>
</div>
<script>
  function getTheme(){return localStorage.getItem('kfb-theme')||'light';}
  function applyTheme(t){document.documentElement.setAttribute('data-theme',t);document.getElementById('themeBtn').textContent=t==='dark'?'☀️':'🌙';localStorage.setItem('kfb-theme',t);}
  function toggleTheme(){applyTheme(getTheme()==='dark'?'light':'dark');}
  applyTheme(getTheme());

  const roles=['owner','manager','sales','admin','produksi'];
  function pilihRole(role,color,label,desc){
    roles.forEach(r=>document.getElementById('btn-'+r).classList.remove('active'));
    document.getElementById('btn-'+role).classList.add('active');
    document.getElementById('roleInput').value=role;
    const box=document.getElementById('selectedRoleBox');
    box.style.display='block';
    box.style.background=color+'22';
    box.style.borderColor=color;
    box.style.color=color;
    document.getElementById('selectedRoleName').textContent=label+' — '+desc;
  }
  // Pre-select if old value exists
  const oldRole='{{ old("role") }}';
  const roleColors={owner:'#F59E0B',manager:'#8B5CF6',sales:'#10B981',admin:'#3B82F6',produksi:'#EF4444'};
  const roleLabels={owner:'Owner',manager:'Manager',sales:'Sales',admin:'Admin',produksi:'Tim Produksi'};
  const roleDescs={owner:'Pantau omzet & laporan',manager:'Proyek, RAB, laporan gaji',sales:'Input customer & deal',admin:'Database & operasional',produksi:'Bahan & jadwal'};
  if(oldRole && roleColors[oldRole]) pilihRole(oldRole,roleColors[oldRole],roleLabels[oldRole],roleDescs[oldRole]);
</script>
</body>
</html>
