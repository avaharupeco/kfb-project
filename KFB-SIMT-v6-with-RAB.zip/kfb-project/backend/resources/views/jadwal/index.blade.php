@extends('layouts.app')
@section('title','Jadwal Pemasangan')
@section('page-title','Jadwal Pemasangan')
@section('topbar-actions')
  <button onclick="document.getElementById('modal-jadwal').style.display='flex'" class="btn btn-primary btn-sm">+ Tambah Jadwal</button>
@endsection
@section('content')
<div class="card">
  @forelse($jadwal as $j)
  <div style="border:1.5px solid var(--line);border-radius:var(--r);padding:16px 18px;margin-bottom:12px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
      <div>
        <div class="td-main" style="font-size:14px">{{ $j->deal->customer->name }}</div>
        <div class="td-sub">{{ $j->deal->jenis_furnitur }} · {{ $j->deal->customer->kode }}</div>
      </div>
      <div style="text-align:right;background:var(--woodll);padding:10px 16px;border-radius:var(--r2);border:1px solid rgba(124,61,18,.15)">
        <div style="font-size:18px;font-weight:800;color:var(--wood)">{{ $j->tgl_pasang->format('d M Y') }}</div>
        <div style="font-size:12px;color:var(--muted)">{{ substr($j->jam_mulai,0,5) }} WIB</div>
      </div>
    </div>
    <div class="info-row"><span class="info-label">Tim Pemasangan</span><span class="info-value">{{ $j->tim_pemasangan }}</span></div>
    <div class="info-row"><span class="info-label">Alamat Lokasi</span><span class="info-value" style="font-size:11px;text-align:right;max-width:60%">{{ $j->alamat_lokasi }}</span></div>
    @if($j->catatan_teknis)
    <div class="info-row"><span class="info-label">Catatan Teknis</span><span class="info-value" style="font-size:11px">{{ $j->catatan_teknis }}</span></div>
    @endif
    <div class="info-row">
      <span class="info-label">Status</span>
      <div style="display:flex;align-items:center;gap:8px">
        <span class="badge badge-{{ $j->status }}">{{ ucfirst($j->status) }}</span>
        @if($j->status !== 'selesai')
          <form action="{{ url('/jadwal/'.$j->id.'/selesai') }}" method="POST">
            @csrf @method('PATCH')
            <button class="btn btn-success btn-xs" data-confirm="Tandai pemasangan ini sebagai selesai?">Tandai Selesai</button>
          </form>
        @endif
      </div>
    </div>
  </div>
  @empty
  <div class="empty-state">Belum ada jadwal pemasangan</div>
  @endforelse
  {{ $jadwal->links() }}
</div>
@endsection
@section('modals')
<div id="modal-jadwal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:500;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:14px;padding:26px;width:540px;max-width:96vw;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
      <h2 style="font-size:15px;font-weight:700">Buat Jadwal Pemasangan</h2>
      <button onclick="document.getElementById('modal-jadwal').style.display='none'" style="background:var(--bg);border:none;width:28px;height:28px;border-radius:50%;cursor:pointer;font-size:14px">✕</button>
    </div>
    <form action="{{ url('/jadwal') }}" method="POST">
      @csrf
      <div class="form-group"><label class="form-label">Proyek</label>
        <select class="form-control" name="deal_id" required>
          <option value="">-- Pilih Proyek --</option>
          @foreach($deals as $d)<option value="{{ $d->id }}">{{ $d->customer->kode }} — {{ $d->customer->name }} ({{ $d->jenis_furnitur }})</option>@endforeach
        </select>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Tanggal Pemasangan</label><input class="form-control" type="date" name="tgl_pasang" required></div>
        <div class="form-group"><label class="form-label">Jam Mulai</label><input class="form-control" type="time" name="jam_mulai" value="08:00" required></div>
      </div>
      <div class="form-group"><label class="form-label">Tim Pemasangan</label><input class="form-control" name="tim_pemasangan" placeholder="Pak Heru, Pak Dedi, Mas Rizki..." required></div>
      <div class="form-group"><label class="form-label">Alamat Lengkap Lokasi</label><textarea class="form-control" name="alamat_lokasi" rows="2" placeholder="Alamat lengkap customer" required></textarea></div>
      <div class="form-group"><label class="form-label">Catatan Teknis</label><input class="form-control" name="catatan_teknis" placeholder="Akses jalan, alat khusus, info tambahan..."></div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:11px">Simpan Jadwal</button>
    </form>
  </div>
</div>
@endsection
