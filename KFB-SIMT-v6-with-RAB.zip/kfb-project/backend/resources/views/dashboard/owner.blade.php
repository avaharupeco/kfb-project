@extends('layouts.app')
@section('title', 'Dashboard Owner')
@section('page-title', 'Dashboard Omzet & Pantauan')

@section('content')
@php
  $stLabels = ['deal'=>'Deal','produksi'=>'Produksi','pemasangan'=>'Pemasangan','selesai'=>'Selesai'];
  $stColors  = ['deal'=>'#3B82F6','produksi'=>'#8B5CF6','pemasangan'=>'#10B981','selesai'=>'#166534'];
  $stClass   = ['deal'=>'badge-deal','produksi'=>'badge-produksi','pemasangan'=>'badge-pemasangan','selesai'=>'badge-selesai'];
@endphp

{{-- Metrik utama --}}
<div class="metric-row col-4">
  <div class="metric">
    <div class="metric-label">Total Nilai Proyek</div>
    <div class="metric-value wood">Rp {{ number_format($totalNilai) }}</div>
    <div class="metric-note">{{ $deals->count() }} proyek terdaftar</div>
  </div>
  <div class="metric">
    <div class="metric-label">Terbayar (FP + DP)</div>
    <div class="metric-value ok">Rp {{ number_format($totalDP) }}</div>
    <div class="metric-note">{{ $totalNilai > 0 ? round($totalDP/$totalNilai*100) : 0 }}% dari total proyek</div>
  </div>
  <div class="metric">
    <div class="metric-label">Proyek Aktif</div>
    <div class="metric-value info">{{ $deals->where('status','!=','selesai')->count() }}</div>
    <div class="metric-note">Rp {{ number_format($deals->where('status','!=','selesai')->sum('nilai_proyek')) }} potensi</div>
  </div>
  <div class="metric">
    <div class="metric-label">Saldo Rekening</div>
    <div class="metric-value wood">Rp {{ number_format($saldoMutasi) }}</div>
    <div class="metric-note">real-time dari mutasi</div>
  </div>
</div>

<div class="grid-2">
  {{-- Distribusi per status --}}
  <div class="card">
    <div class="card-header">
      <div class="card-title">Distribusi Status Proyek</div>
    </div>
    @foreach(['deal','produksi','pemasangan','selesai'] as $s)
      @php
        $val = $omzetPerStatus[$s] ?? 0;
        $pct = $totalNilai > 0 ? round($val / $totalNilai * 100) : 0;
      @endphp
      <div class="stat-bar">
        <div class="stat-label">
          <span>{{ $stLabels[$s] }} ({{ $deals->where('status',$s)->count() }} proyek)</span>
          <span style="font-weight:700">Rp {{ number_format($val) }} · {{ $pct }}%</span>
        </div>
        <div class="stat-track">
          <div class="stat-fill" style="width:{{ $pct }}%; background:{{ $stColors[$s] }}"></div>
        </div>
      </div>
    @endforeach
  </div>

  {{-- 5 proyek terbesar --}}
  <div class="card">
    <div class="card-header">
      <div class="card-title">5 Proyek Terbesar</div>
      <a href="{{ url('/deals') }}" class="btn btn-secondary btn-sm">Semua →</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>Customer</th><th>Proyek</th><th>Nilai</th><th>Status</th></tr>
        </thead>
        <tbody>
          @foreach($deals->sortByDesc('nilai_proyek')->take(5) as $deal)
          <tr>
            <td>
              <div class="td-main">{{ $deal->customer->name }}</div>
              <div class="td-sub">{{ $deal->customer->kode }}</div>
            </td>
            <td style="font-size:11px">{{ Str::limit($deal->jenis_furnitur, 22) }}</td>
            <td><strong>Rp {{ number_format($deal->nilai_proyek) }}</strong></td>
            <td><span class="badge {{ $stClass[$deal->status] }}">{{ $stLabels[$deal->status] }}</span></td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>

{{-- Mutasi terbaru --}}
<div class="card">
  <div class="card-header">
    <div class="card-title">Mutasi Rekening Terbaru</div>
    <a href="{{ url('/mutasi') }}" class="btn btn-secondary btn-sm">Semua →</a>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Tanggal</th><th>Keterangan</th><th>Jenis</th><th style="text-align:right">Jumlah</th></tr>
      </thead>
      <tbody>
        @forelse($mutasi as $m)
        <tr>
          <td style="font-size:11px">{{ $m->tanggal->format('d M Y') }}</td>
          <td>{{ $m->keterangan }}</td>
          <td>
            <span class="badge {{ $m->type==='masuk' ? 'badge-masuk' : 'badge-keluar' }}">
              {{ $m->type === 'masuk' ? 'Masuk' : 'Keluar' }}
            </span>
          </td>
          <td style="text-align:right; font-weight:700; color:{{ $m->type==='masuk' ? 'var(--ok)' : 'var(--err)' }}">
            {{ $m->type === 'masuk' ? '+' : '-' }} Rp {{ number_format($m->jumlah) }}
          </td>
        </tr>
        @empty
        <tr><td colspan="4" class="empty-state">Belum ada mutasi rekening</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection
