@extends('layouts.app')
@section('title','Dashboard Sales')
@section('page-title','Dashboard Sales')
@section('topbar-actions')
  <a href="{{ url('/deals/create') }}" class="btn btn-primary btn-sm">+ Input Deal Baru</a>
@endsection
@section('content')
@php
  $stClass=['deal'=>'badge-deal','produksi'=>'badge-produksi','pemasangan'=>'badge-pemasangan','selesai'=>'badge-selesai'];
  $stLabel=['deal'=>'Deal','produksi'=>'Produksi','pemasangan'=>'Pemasangan','selesai'=>'Selesai'];
@endphp
<div class="metric-row col-4">
  <div class="metric"><div class="metric-label">Total Deal Saya</div><div class="metric-value wood">{{ $deals->count() }}</div><div class="metric-note">semua proyek</div></div>
  <div class="metric"><div class="metric-label">Nilai Total</div><div class="metric-value">Rp {{ number_format($deals->sum('nilai_proyek')) }}</div></div>
  <div class="metric"><div class="metric-label">FP / DP</div><div class="metric-value">{{ $deals->where('jenis_deal','FP')->count() }} / {{ $deals->where('jenis_deal','DP')->count() }}</div></div>
  <div class="metric"><div class="metric-label">Outstanding</div><div class="metric-value err">Rp {{ number_format($deals->sum(fn($d)=>$d->sisa())) }}</div><div class="metric-note">sisa pelunasan</div></div>
</div>
<div class="card">
  <div class="card-header"><div class="card-title">Semua Deal Saya</div></div>
  <div class="filter-bar">
    <input class="search-input" placeholder="Cari nama / kode..." data-search-table="tbl-deals">
    <a href="{{ url('/deals') }}" class="chip {{ !request('status') ? 'active' : '' }}">Semua</a>
    @foreach(['deal','produksi','pemasangan','selesai'] as $s)
      <a href="{{ url('/deals?status='.$s) }}" class="chip {{ request('status')===$s ? 'active' : '' }}">{{ $stLabel[$s] }}</a>
    @endforeach
  </div>
  <div class="table-wrap">
    <table id="tbl-deals">
      <thead><tr><th>Kode</th><th>Customer</th><th>Jenis Furnitur</th><th>Nilai</th><th>DP</th><th>Sisa</th><th>Deal</th><th>Manager</th><th>Garansi</th><th>Status</th><th>Tgl</th></tr></thead>
      <tbody>
        @forelse($deals as $d)
        <tr>
          <td style="font-size:10px;color:var(--muted);font-weight:600">{{ $d->customer->kode }}</td>
          <td><div class="td-main">{{ $d->customer->name }}</div><div class="td-sub">{{ $d->customer->phone }}</div></td>
          <td style="font-size:11px;max-width:160px">{{ $d->jenis_furnitur }}</td>
          <td><strong>Rp {{ number_format($d->nilai_proyek) }}</strong></td>
          <td style="color:var(--ok);font-size:11px">Rp {{ number_format($d->dp_amount) }}</td>
          <td style="color:{{ $d->sisa()>0?'var(--err)':'var(--ok)' }};font-size:11px">Rp {{ number_format($d->sisa()) }}</td>
          <td><span class="badge {{ $d->jenis_deal==='FP'?'badge-fp':'badge-dp' }}">{{ $d->jenis_deal }}</span></td>
          <td style="font-size:11px">{{ $d->manager?->name ?? '-' }}</td>
          <td style="font-size:11px">{{ $d->garansi_hari }} hari</td>
          <td><span class="badge {{ $stClass[$d->status] }}">{{ $stLabel[$d->status] }}</span></td>
          <td style="font-size:11px">{{ $d->tgl_persetujuan->format('d/m/Y') }}</td>
        </tr>
        @empty
        <tr><td colspan="11" class="empty-state">Belum ada deal</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
<div class="card">
  <div class="card-header"><div class="card-title">Status Garansi Customer</div></div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Kode</th><th>Customer</th><th>Proyek</th><th>Masa Garansi</th><th>Berlaku Hingga</th><th>Sisa Hari</th><th>Status</th></tr></thead>
      <tbody>
        @foreach($garansiData as $g)
        <tr>
          <td style="font-size:10px;color:var(--muted)">{{ $g['deal']->customer->kode }}</td>
          <td class="td-main">{{ $g['deal']->customer->name }}</td>
          <td style="font-size:11px">{{ Str::limit($g['deal']->jenis_furnitur,28) }}</td>
          <td style="font-size:11px">{{ $g['deal']->garansi_hari }} hari</td>
          <td style="font-size:11px">{{ $g['akhir'] }}</td>
          <td style="font-weight:700;color:{{ $g['aktif'] ? ($g['sisa']<14?'var(--err)':'var(--ok)') : 'var(--muted)' }}">
            {{ $g['aktif'] ? $g['sisa'].' hari' : 'Habis' }}
          </td>
          <td><span class="badge {{ $g['aktif']?'badge-approved':'badge-ditolak' }}">{{ $g['aktif']?'Aktif':'Expired' }}</span></td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>
@endsection
