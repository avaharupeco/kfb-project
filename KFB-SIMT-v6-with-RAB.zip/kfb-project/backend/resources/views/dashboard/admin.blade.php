@extends('layouts.app')
@section('title','Dashboard Admin')
@section('page-title','Dashboard Admin')
@section('content')
<div class="metric-row col-4">
  <div class="metric"><div class="metric-label">Total Proyek Dikelola</div><div class="metric-value wood">{{ $deals->count() }}</div><div class="metric-note">Rp {{ number_format($deals->sum('nilai_proyek')) }}</div></div>
  <div class="metric"><div class="metric-label">Saldo Rekening</div><div class="metric-value ok">Rp {{ number_format($saldoMutasi) }}</div></div>
  <div class="metric"><div class="metric-label">Saldo Petty Cash</div><div class="metric-value {{ $pettySaldo>=0?'info':'err' }}">Rp {{ number_format(abs($pettySaldo)) }}</div></div>
  <div class="metric"><div class="metric-label">Pengajuan Bahan Pending</div><div class="metric-value {{ $bahanPending->count()>0?'err':'ok' }}">{{ $bahanPending->count() }}</div><div class="metric-note">perlu diproses</div></div>
</div>
<div class="grid-2">
  <div class="card">
    <div class="card-header"><div class="card-title">Pengajuan Bahan Pending</div><a href="{{ url('/bahan') }}" class="btn btn-secondary btn-sm">Semua →</a></div>
    @forelse($bahanPending as $b)
    <div style="padding:12px 0;border-bottom:1px solid var(--line)">
      <div style="display:flex;justify-content:space-between;margin-bottom:4px">
        <div><div class="td-main">{{ $b->nama_bahan }}</div><div class="td-sub">{{ $b->qty }} {{ $b->satuan }} · {{ $b->deal->customer->name }}</div></div>
        <strong style="color:var(--wood)">Rp {{ number_format($b->total_harga) }}</strong>
      </div>
      @if($b->keinginan_customer)
        <div style="font-size:10.5px;color:var(--hint);font-style:italic;margin-bottom:7px">"{{ $b->keinginan_customer }}"</div>
      @endif
      <div style="display:flex;gap:6px">
        <form action="{{ url('/bahan/'.$b->id.'/approve') }}" method="POST">@csrf @method('PATCH')<button class="btn btn-success btn-xs">✓ Setujui</button></form>
        <form action="{{ url('/bahan/'.$b->id.'/reject') }}" method="POST">@csrf @method('PATCH')<button class="btn btn-danger btn-xs">✗ Tolak</button></form>
      </div>
    </div>
    @empty
    <div class="empty-state">Semua pengajuan sudah diproses</div>
    @endforelse
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title">Absensi Hari Ini</div><a href="{{ url('/absen') }}" class="btn btn-secondary btn-sm">Input →</a></div>
    @if($absenHariIni->count())
      <div style="font-size:11px;color:var(--hint);margin-bottom:10px">{{ today()->format('d F Y') }} — {{ $absenHariIni->where('status','hadir')->count() }} hadir dari {{ $absenHariIni->count() }}</div>
      @foreach($absenHariIni as $a)
      <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--line);font-size:12px">
        <span>{{ $a->user->name }}</span>
        <span class="badge badge-{{ $a->status }}">{{ ucfirst($a->status) }}</span>
      </div>
      @endforeach
    @else
      <div class="empty-state">Belum ada absensi hari ini<br><a href="{{ url('/absen') }}" class="btn btn-primary btn-sm" style="margin-top:10px">Input Absensi</a></div>
    @endif
  </div>
</div>
@endsection
