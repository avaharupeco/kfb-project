@extends('layouts.app')
@section('title','Dashboard Produksi')
@section('page-title','Dashboard Tim Produksi')
@section('content')
@php $progs=['deal'=>10,'produksi'=>55,'pemasangan'=>90,'selesai'=>100]; $cols=['deal'=>'#3B82F6','produksi'=>'#8B5CF6','pemasangan'=>'#10B981','selesai'=>'#166534']; $lbls=['deal'=>'Antrian','produksi'=>'Diproduksi','pemasangan'=>'Siap Pasang','selesai'=>'Selesai']; @endphp
<div class="metric-row col-3">
  <div class="metric"><div class="metric-label">Proyek Aktif</div><div class="metric-value wood">{{ $aktif->count() }}</div><div class="metric-note">perlu dikerjakan</div></div>
  <div class="metric"><div class="metric-label">Pengajuan Bahan</div><div class="metric-value {{ $bahan->where('status','diajukan')->count()>0?'err':'ok' }}">{{ $bahan->where('status','diajukan')->count() }}</div><div class="metric-note">menunggu persetujuan</div></div>
  <div class="metric"><div class="metric-label">Jadwal Pemasangan</div><div class="metric-value info">{{ $jadwal->count() }}</div><div class="metric-note">terjadwal</div></div>
</div>
{{-- Kanban --}}
<div class="kanban" style="margin-bottom:14px">
  @foreach(['deal','produksi','pemasangan','selesai'] as $stage)
  <div class="kanban-col">
    <div class="kanban-col-header">
      <span class="kanban-col-title" style="color:{{ $cols[$stage] }}">{{ $lbls[$stage] }}</span>
      <span class="kanban-count">{{ $kanban[$stage]->count() }}</span>
    </div>
    @forelse($kanban[$stage] as $d)
    <div class="kanban-card">
      <div class="kanban-card-name">{{ $d->customer->name }}</div>
      <div class="kanban-card-sub">{{ Str::limit($d->jenis_furnitur,30) }}</div>
      <div class="progress-bar"><div class="progress-fill" style="width:{{ $progs[$stage] }}%;background:{{ $cols[$stage] }}"></div></div>
      <div class="kanban-card-foot">
        <span style="font-size:10px;color:var(--hint)">{{ $d->customer->kode }}</span>
        <span style="font-size:10px;color:var(--wood);font-weight:600">Rp {{ number_format($d->nilai_proyek) }}</span>
      </div>
    </div>
    @empty
    <div class="empty-state" style="padding:20px 0">Kosong</div>
    @endforelse
  </div>
  @endforeach
</div>
<div class="grid-2">
  <div class="card">
    <div class="card-header"><div class="card-title">Kebutuhan Bahan Terbaru</div><a href="{{ url('/bahan') }}" class="btn btn-primary btn-sm">+ Ajukan Bahan</a></div>
    @forelse($bahan->take(5) as $b)
    <div style="padding:8px 0;border-bottom:1px solid var(--line)">
      <div style="display:flex;justify-content:space-between;margin-bottom:3px">
        <div class="td-main">{{ $b->nama_bahan }}</div>
        <span class="badge badge-{{ $b->status }}">{{ $b->status }}</span>
      </div>
      <div style="font-size:11px;color:var(--muted)">{{ $b->qty }} {{ $b->satuan }} · Rp {{ number_format($b->total_harga) }}</div>
    </div>
    @empty
    <div class="empty-state">Belum ada pengajuan bahan</div>
    @endforelse
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title">Jadwal Pemasangan</div><a href="{{ url('/jadwal') }}" class="btn btn-primary btn-sm">+ Tambah Jadwal</a></div>
    @forelse($jadwal->take(3) as $j)
    <div style="padding:10px 0;border-bottom:1px solid var(--line)">
      <div style="display:flex;justify-content:space-between;margin-bottom:4px">
        <div class="td-main">{{ $j->deal->customer->name }}</div>
        <strong style="color:var(--wood)">{{ $j->tgl_pasang->format('d M') }}</strong>
      </div>
      <div style="font-size:11px;color:var(--muted)">{{ $j->tim_pemasangan }}</div>
      <div style="font-size:10px;color:var(--hint)">{{ Str::limit($j->alamat_lokasi,50) }}</div>
    </div>
    @empty
    <div class="empty-state">Belum ada jadwal</div>
    @endforelse
  </div>
</div>
@endsection
