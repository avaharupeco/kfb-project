@extends('layouts.app')
@section('title','Dashboard Manager')
@section('page-title','Dashboard Hasil Proyek')
@section('content')
@php $stClass=['deal'=>'badge-deal','produksi'=>'badge-produksi','pemasangan'=>'badge-pemasangan','selesai'=>'badge-selesai']; $stLabel=['deal'=>'Deal','produksi'=>'Produksi','pemasangan'=>'Pemasangan','selesai'=>'Selesai']; @endphp
<div class="metric-row col-3">
  <div class="metric"><div class="metric-label">Total Proyek</div><div class="metric-value wood">{{ $deals->count() }}</div><div class="metric-note">Rp {{ number_format($deals->sum('nilai_proyek')) }}</div></div>
  <div class="metric"><div class="metric-label">Berjalan</div><div class="metric-value info">{{ $deals->where('status','!=','selesai')->count() }}</div></div>
  <div class="metric"><div class="metric-label">Selesai</div><div class="metric-value ok">{{ $deals->where('status','selesai')->count() }}</div></div>
</div>
{{-- RAB breakdown --}}
<div class="card">
  <div class="card-header"><div class="card-title">RAB Breakdown Semua Proyek</div></div>
  @foreach($rabData as $r)
  <div style="border:1.5px solid var(--line);border-radius:var(--r);padding:14px 16px;margin-bottom:10px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
      <div><div class="td-main">{{ $r['deal']->customer->name }} — {{ Str::limit($r['deal']->jenis_furnitur,35) }}</div><div class="td-sub">{{ $r['deal']->customer->kode }} · {{ $r['deal']->tgl_persetujuan->format('d M Y') }}</div></div>
      <span class="badge {{ $stClass[$r['deal']->status] }}">{{ $stLabel[$r['deal']->status] }}</span>
    </div>
    <div class="grid-2" style="gap:8px">
      @foreach([['Material',0.40,'#7C3D12'],['Jasa',0.27,'#8B5CF6'],['Finishing',0.18,'#10B981'],['Lain-lain',0.15,'#6B7280']] as [$lbl,$pct,$c])
      <div style="background:var(--bg);border-radius:var(--r2);padding:8px 12px">
        <div style="font-size:10px;font-weight:600;color:var(--muted);margin-bottom:3px">{{ $lbl }}</div>
        <div style="font-size:15px;font-weight:700;color:{{ $c }}">Rp {{ number_format(round($r['deal']->nilai_proyek*$pct)) }}</div>
      </div>
      @endforeach
    </div>
    <div class="sum-box" style="margin:10px 0 0">
      <div class="sum-row"><span class="sum-label">Nilai Proyek</span><strong>Rp {{ number_format($r['deal']->nilai_proyek) }}</strong></div>
      <div class="sum-row"><span class="sum-label">DP Diterima</span><span style="color:var(--ok)">Rp {{ number_format($r['deal']->dp_amount) }}</span></div>
      <div class="sum-row"><span class="sum-label">Sisa</span><span style="color:{{ $r['deal']->sisa()>0?'var(--err)':'var(--ok)' }}">Rp {{ number_format($r['deal']->sisa()) }}</span></div>
    </div>
  </div>
  @endforeach
</div>
{{-- Laporan gaji --}}
<div class="card">
  <div class="card-header"><div class="card-title">Laporan Gaji Tim Produksi — {{ now()->format('F Y') }}</div></div>
  @php $totalGaji = array_sum(array_map(fn($k)=>($k['base']*$k['order'])+$k['bonus'], $staffGaji)); @endphp
  <div class="table-wrap"><table>
    <thead><tr><th>Nama</th><th>Role</th><th>Order</th><th>Rate/Order</th><th>Gaji Pokok</th><th>Bonus</th><th>Total</th></tr></thead>
    <tbody>
      @foreach($staffGaji as $k)
      <tr>
        <td class="td-main">{{ $k['nama'] }}</td>
        <td style="font-size:11px;color:var(--muted)">{{ $k['role'] }}</td>
        <td style="text-align:center;font-weight:700;font-size:14px">{{ $k['order'] }}</td>
        <td style="font-size:11px">Rp {{ number_format($k['base']) }}</td>
        <td>Rp {{ number_format($k['base']*$k['order']) }}</td>
        <td>{{ $k['bonus']>0 ? '<span style="color:var(--ok);font-weight:600">+Rp '.number_format($k['bonus']).'</span>' : '—' }}</td>
        <td><strong style="color:var(--wood)">Rp {{ number_format(($k['base']*$k['order'])+$k['bonus']) }}</strong></td>
      </tr>
      @endforeach
      <tr style="background:var(--woodll)"><td colspan="6" style="font-weight:700;color:var(--wood)">TOTAL</td><td style="font-weight:800;color:var(--wood);font-size:14px">Rp {{ number_format($totalGaji) }}</td></tr>
    </tbody>
  </table></div>
</div>
@endsection
