<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>KFB SIMT — @yield('title', 'Dashboard')</title>

  {{-- Favicon --}}
  <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">
  <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('favicon-32x32.png') }}">
  <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('favicon-16x16.png') }}">
  <link rel="apple-touch-icon" sizes="192x192" href="{{ asset('favicon-192x192.png') }}">

  {{-- Google Fonts --}}
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  {{-- CSS utama (dipisah dari template) --}}
  <link rel="stylesheet" href="{{ asset('css/app.css') }}">

  {{-- CSS tambahan per halaman (opsional) --}}
  @yield('styles')
</head>
<body>

{{-- ═══════════════════════════════════════════════════════════ --}}
{{-- SIDEBAR                                                     --}}
{{-- ═══════════════════════════════════════════════════════════ --}}
<aside id="sidebar">
  <div class="sb-top">
    <div class="sb-logo-icon">
      <img src="{{ asset('images/kfb.png') }}" alt="KFB Logo" style="width:44px;height:44px;object-fit:contain;border-radius:6px;">
    </div>
    <div class="sb-brand">Kurnia Furniture</div>
    <div class="sb-city">BOGOR · SIMT v2.0</div>
  </div>

  <nav class="sb-nav" aria-label="Menu navigasi">
    {{-- MENU UTAMA --}}
    <div class="sb-section">UTAMA</div>
    <a href="{{ url('/dashboard') }}" class="nav-item {{ request()->is('dashboard') ? 'active' : '' }}">
      <svg viewBox="0 0 15 15" fill="none" aria-hidden="true"><polyline points="1,12 5,7.5 7.5,10 11,4 14,6.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
      Dashboard
    </a>

    {{-- OWNER: Pantauan keuangan --}}
    @can_role(['owner'])
      <div class="sb-section">PANTAUAN</div>
      <a href="{{ url('/mutasi') }}" class="nav-item {{ request()->is('mutasi*') ? 'active' : '' }}">
        <svg viewBox="0 0 15 15" fill="none" aria-hidden="true"><rect x="1.5" y="4" width="12" height="8" rx="1.5" stroke="currentColor" stroke-width="1.3"/><line x1="1.5" y1="7" x2="13.5" y2="7" stroke="currentColor" stroke-width="1.2"/></svg>
        Arus Kas & Mutasi
      </a>
    @endcan_role

    {{-- MANAGER, SALES: Proyek & deal --}}
    @can_role(['owner','manager','sales','admin'])
      <div class="sb-section">PENJUALAN</div>
      <a href="{{ url('/deals') }}" class="nav-item {{ request()->is('deals*') ? 'active' : '' }}">
        <svg viewBox="0 0 15 15" fill="none" aria-hidden="true"><rect x="1.5" y="1.5" width="12" height="12" rx="1.5" stroke="currentColor" stroke-width="1.3"/><line x1="4.5" y1="5.5" x2="10.5" y2="5.5" stroke="currentColor" stroke-width="1.2"/><line x1="4.5" y1="8.5" x2="8" y2="8.5" stroke="currentColor" stroke-width="1.2"/></svg>
        Data Customer & Deal
      </a>
    @endcan_role

    {{-- ADMIN: Database operasional --}}
    @can_role(['owner','admin'])
      <div class="sb-section">ADMIN DATABASE</div>
      <a href="{{ url('/rab') }}" class="nav-item {{ request()->is('rab*') ? 'active' : '' }}">
        <svg viewBox="0 0 15 15" fill="none" aria-hidden="true"><rect x="1.5" y="1.5" width="12" height="12" rx="1.5" stroke="currentColor" stroke-width="1.3"/><line x1="1.5" y1="5.5" x2="13.5" y2="5.5" stroke="currentColor" stroke-width="1.1"/><line x1="1.5" y1="9" x2="13.5" y2="9" stroke="currentColor" stroke-width="1.1"/><line x1="5" y1="5.5" x2="5" y2="13.5" stroke="currentColor" stroke-width="1.1"/></svg>
        RAB
      </a>
      <a href="{{ url('/absen') }}" class="nav-item {{ request()->is('absen*') ? 'active' : '' }}">
        <svg viewBox="0 0 15 15" fill="none" aria-hidden="true"><circle cx="5.5" cy="5" r="2.5" stroke="currentColor" stroke-width="1.3"/><path d="M1 13c0-2.5 2-4.5 4.5-4.5S10 10.5 10 13" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" fill="none"/><circle cx="11.5" cy="4.5" r="1.8" stroke="currentColor" stroke-width="1.2"/></svg>
        Absensi Karyawan
      </a>
      <a href="{{ url('/petty') }}" class="nav-item {{ request()->is('petty*') ? 'active' : '' }}">
        <svg viewBox="0 0 15 15" fill="none" aria-hidden="true"><rect x="1.5" y="4" width="12" height="8" rx="1.5" stroke="currentColor" stroke-width="1.3"/><line x1="1.5" y1="7" x2="13.5" y2="7" stroke="currentColor" stroke-width="1.2"/><circle cx="5" cy="10" r="1" fill="currentColor" opacity=".6"/></svg>
        Petty Cash Harian
      </a>
      <a href="{{ url('/mutasi') }}" class="nav-item {{ request()->is('mutasi*') ? 'active' : '' }}">
        <svg viewBox="0 0 15 15" fill="none" aria-hidden="true"><polygon points="7.5,1.5 13.5,5 1.5,5" fill="currentColor" opacity=".4"/><rect x="1.5" y="11" width="12" height="2.5" rx=".8" fill="currentColor" opacity=".4"/><rect x="3" y="5" width="1.5" height="6" fill="currentColor" opacity=".5"/><rect x="7" y="5" width="1.5" height="6" fill="currentColor" opacity=".5"/><rect x="11" y="5" width="1.5" height="6" fill="currentColor" opacity=".5"/></svg>
        Mutasi Rekening
      </a>
    @endcan_role

    {{-- PRODUKSI: Bahan & pemasangan --}}
    @can_role(['owner','admin','produksi'])
      <div class="sb-section">PRODUKSI</div>
      <a href="{{ url('/bahan') }}" class="nav-item {{ request()->is('bahan*') ? 'active' : '' }}">
        <svg viewBox="0 0 15 15" fill="none" aria-hidden="true"><rect x="1.5" y="6" width="12" height="7.5" rx="1.2" stroke="currentColor" stroke-width="1.3"/><path d="M5 6V4.5a2.5 2.5 0 015 0V6" stroke="currentColor" stroke-width="1.2"/></svg>
        Kebutuhan Bahan
      </a>
      <a href="{{ url('/jadwal') }}" class="nav-item {{ request()->is('jadwal*') ? 'active' : '' }}">
        <svg viewBox="0 0 15 15" fill="none" aria-hidden="true"><rect x="1.5" y="3" width="12" height="10.5" rx="1.5" stroke="currentColor" stroke-width="1.3"/><line x1="1.5" y1="6.5" x2="13.5" y2="6.5" stroke="currentColor" stroke-width="1.2"/><line x1="5" y1="1.5" x2="5" y2="4.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><line x1="10" y1="1.5" x2="10" y2="4.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>
        Jadwal Pemasangan
      </a>
    @endcan_role
  </nav>

  <div class="sb-bottom">
    <div class="sb-user">
      <div class="sb-avatar" aria-hidden="true">
        {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
      </div>
      <div>
        <div class="sb-username">{{ auth()->user()->name }}</div>
        <div class="sb-userrole">{{ ucfirst(auth()->user()->role) }}</div>
      </div>
    </div>
    <form action="{{ url('/logout') }}" method="POST">
      @csrf
      <button type="submit" class="sb-logout">← Keluar dari sistem</button>
    </form>
  </div>
</aside>

{{-- ═══════════════════════════════════════════════════════════ --}}
{{-- MAIN CONTENT                                               --}}
{{-- ═══════════════════════════════════════════════════════════ --}}
<div id="main">
  <header class="topbar">
    <h1 class="topbar-title">@yield('page-title', 'Dashboard')</h1>
    <div class="topbar-right">
      <span class="role-tag">{{ ucfirst(str_replace('_', ' ', auth()->user()->role)) }}</span>
      @yield('topbar-actions')
      <button onclick="toggleTheme()" id="themeBtn" title="Ganti tema gelap/terang"
        style="background:none;border:1.5px solid rgba(128,128,128,.3);border-radius:8px;padding:5px 10px;cursor:pointer;font-size:14px;transition:all .2s;margin-left:8px;">
        🌙
      </button>
    </div>
  </header>

  <main class="content" id="main-content">
    {{-- Flash messages --}}
    @if(session('success'))
      <div class="alert alert-success" role="alert">✓ {{ session('success') }}</div>
    @endif
    @if(session('error'))
      <div class="alert alert-error" role="alert">{{ session('error') }}</div>
    @endif
    @if($errors->any())
      <div class="alert alert-error" role="alert">{{ $errors->first() }}</div>
    @endif

    @yield('content')
  </main>
</div>

{{-- Modals per halaman --}}
@yield('modals')

{{-- JS utama (dipisah dari template) --}}
<script>
  function getTheme(){return localStorage.getItem('kfb-theme')||'light';}
  function applyTheme(t){document.documentElement.setAttribute('data-theme',t);var btn=document.getElementById('themeBtn');if(btn)btn.textContent=t==='dark'?'☀️':'🌙';localStorage.setItem('kfb-theme',t);}
  function toggleTheme(){applyTheme(getTheme()==='dark'?'light':'dark');}
  applyTheme(getTheme());
</script>
<script src="{{ asset('js/app.js') }}"></script>
@yield('scripts')

</body>
</html>
