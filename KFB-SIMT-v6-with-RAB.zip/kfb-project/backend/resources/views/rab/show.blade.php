@extends('layouts.app')
@section('title','Detail RAB — '.$rab->deal->customer->name)
@section('page-title','Detail RAB')
@section('topbar-actions')
  <a href="{{ url('/rab/'.$rab->id.'/edit') }}" class="btn btn-primary btn-sm">Edit RAB</a>
  <a href="{{ url('/rab') }}" class="btn btn-secondary btn-sm">← Kembali</a>
@endsection

@section('content')
@php
  $stClass = ['draft'=>'badge-deal','terkirim'=>'badge-produksi','acc'=>'badge-selesai'];
  $stLabel = ['draft'=>'Draft','terkirim'=>'Terkirim','acc'=>'ACC'];
@endphp

<div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;max-width:1000px">

  {{-- KIRI: Rincian Pekerjaan --}}
  <div>
    <div class="card">
      <div style="padding:16px 20px;border-bottom:1px solid var(--border)">
        <h3 style="margin:0;font-size:14px;font-weight:600">Rincian Pekerjaan</h3>
      </div>
      <div style="padding:16px 20px;display:grid;gap:14px">

        <div>
          <div style="font-size:11px;color:var(--muted);margin-bottom:3px">Pekerjaan</div>
          <div style="font-size:13px;font-weight:600">{{ $rab->pekerjaan ?: $rab->deal->jenis_furnitur }}</div>
        </div>

        <div>
          <div style="font-size:11px;color:var(--muted);margin-bottom:3px">Item Pekerjaan</div>
          <div style="font-size:13px;white-space:pre-wrap">{{ $rab->item_pekerjaan ?: $rab->deal->item_pekerjaan ?: '-' }}</div>
        </div>

        <div>
          <div style="font-size:11px;color:var(--muted);margin-bottom:3px">Detail Pekerjaan</div>
          <div style="font-size:13px;white-space:pre-wrap;color:var(--muted)">{{ $rab->detail_pekerjaan ?: $rab->deal->detail_pekerjaan ?: '-' }}</div>
        </div>

        <div style="display:flex;gap:32px">
          <div>
            <div style="font-size:11px;color:var(--muted);margin-bottom:3px">Waktu Pengerjaan</div>
            <div style="font-size:16px;font-weight:700">{{ $rab->waktu_pengerjaan }} <span style="font-size:12px;font-weight:400">hari</span></div>
          </div>
          <div>
            <div style="font-size:11px;color:var(--muted);margin-bottom:3px">Status RAB</div>
            <span class="badge {{ $stClass[$rab->status] }}">{{ $stLabel[$rab->status] }}</span>
          </div>
        </div>

      </div>
    </div>

    {{-- Rincian Biaya --}}
    <div class="card" style="margin-top:16px">
      <div style="padding:16px 20px;border-bottom:1px solid var(--border)">
        <h3 style="margin:0;font-size:14px;font-weight:600">Rincian Biaya</h3>
      </div>
      <div style="padding:16px 20px">
        <table style="width:100%;border-collapse:collapse">
          <tbody>
            @foreach([
              ['Biaya Material',      $rab->cost_material],
              ['Biaya Tenaga Kerja',  $rab->cost_labor],
              ['Biaya Finishing',     $rab->cost_finishing],
              ['Biaya Lain-lain',     $rab->cost_other],
            ] as [$label, $val])
            <tr style="border-bottom:1px solid var(--border)">
              <td style="padding:10px 0;font-size:13px">{{ $label }}</td>
              <td style="padding:10px 0;font-size:13px;text-align:right">Rp {{ number_format($val) }}</td>
            </tr>
            @endforeach
          </tbody>
          <tfoot>
            <tr>
              <td style="padding:12px 0;font-size:14px;font-weight:700">TOTAL RAB</td>
              <td style="padding:12px 0;font-size:18px;font-weight:700;text-align:right;color:var(--accent)">
                Rp {{ number_format($rab->total) }}
              </td>
            </tr>
          </tfoot>
        </table>

        {{-- Perbandingan dengan nilai proyek --}}
        @php $selisih = $rab->deal->nilai_proyek - $rab->total; @endphp
        <div style="margin-top:12px;padding:10px 12px;background:var(--surface);border-radius:6px;font-size:12px">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <span style="color:var(--muted)">Nilai Proyek (Deal)</span>
            <strong>Rp {{ number_format($rab->deal->nilai_proyek) }}</strong>
          </div>
          <div style="display:flex;justify-content:space-between">
            <span style="color:var(--muted)">Selisih (Profit Estimasi)</span>
            <strong style="color:{{ $selisih >= 0 ? 'var(--ok)' : 'var(--err)' }}">
              {{ $selisih >= 0 ? '+' : '' }}Rp {{ number_format($selisih) }}
            </strong>
          </div>
        </div>
      </div>
    </div>
  </div>

  {{-- KANAN: Info Customer & Deal --}}
  <div>
    <div class="card">
      <div style="padding:16px 20px;border-bottom:1px solid var(--border)">
        <h3 style="margin:0;font-size:14px;font-weight:600">Info Customer</h3>
      </div>
      <div style="padding:16px 20px;display:grid;gap:10px;font-size:12px">
        <div>
          <div style="color:var(--muted);margin-bottom:2px">Nama</div>
          <div style="font-weight:600">{{ $rab->deal->customer->name }}</div>
        </div>
        <div>
          <div style="color:var(--muted);margin-bottom:2px">Kode</div>
          <div>{{ $rab->deal->customer->kode }}</div>
        </div>
        <div>
          <div style="color:var(--muted);margin-bottom:2px">No. HP</div>
          <div>{{ $rab->deal->customer->phone }}</div>
        </div>
        <div>
          <div style="color:var(--muted);margin-bottom:2px">Alamat</div>
          <div>{{ $rab->deal->customer->address ?? '-' }}</div>
        </div>
      </div>
    </div>

    <div class="card" style="margin-top:16px">
      <div style="padding:16px 20px;border-bottom:1px solid var(--border)">
        <h3 style="margin:0;font-size:14px;font-weight:600">Info Deal</h3>
      </div>
      <div style="padding:16px 20px;display:grid;gap:10px;font-size:12px">
        <div>
          <div style="color:var(--muted);margin-bottom:2px">Sales</div>
          <div style="font-weight:600">{{ $rab->deal->sales?->name ?? '-' }}</div>
        </div>
        <div>
          <div style="color:var(--muted);margin-bottom:2px">Manager</div>
          <div>{{ $rab->deal->manager?->name ?? '-' }}</div>
        </div>
        <div>
          <div style="color:var(--muted);margin-bottom:2px">Nilai Proyek</div>
          <div style="font-weight:700;color:var(--accent)">Rp {{ number_format($rab->deal->nilai_proyek) }}</div>
        </div>
        <div>
          <div style="color:var(--muted);margin-bottom:2px">Jenis Deal</div>
          <span class="badge {{ $rab->deal->jenis_deal==='FP'?'badge-fp':'badge-dp' }}">{{ $rab->deal->jenis_deal }}</span>
        </div>
        <div>
          <div style="color:var(--muted);margin-bottom:2px">Tgl Persetujuan</div>
          <div>{{ $rab->deal->tgl_persetujuan->format('d M Y') }}</div>
        </div>
      </div>
    </div>

    {{-- Tombol hapus --}}
    <form method="POST" action="{{ url('/rab/'.$rab->id) }}" style="margin-top:16px"
          onsubmit="return confirm('Yakin ingin menghapus RAB ini?')">
      @csrf @method('DELETE')
      <button type="submit" class="btn btn-sm" style="width:100%;background:var(--err);color:#fff">
        Hapus RAB Ini
      </button>
    </form>
  </div>

</div>
@endsection
