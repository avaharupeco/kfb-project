@extends('layouts.app')
@section('title','Edit RAB — '.$rab->deal->customer->name)
@section('page-title','Edit RAB')

@section('content')
<div class="card" style="max-width:860px;margin:0 auto">
  <div style="padding:20px 24px 0;border-bottom:1px solid var(--border);margin-bottom:20px">
    <h3 style="margin:0 0 4px;font-size:15px">Edit RAB — {{ $rab->deal->customer->name }}</h3>
    <p style="margin:0 0 16px;font-size:12px;color:var(--muted)">
      {{ $rab->deal->customer->kode }} &mdash; {{ $rab->deal->jenis_furnitur }}
    </p>
  </div>

  @if($errors->any())
    <div style="margin:0 24px 16px;padding:10px 14px;background:#fee;border:1px solid var(--err);border-radius:6px;font-size:12px;color:var(--err)">
      <ul style="margin:0;padding-left:16px">
        @foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach
      </ul>
    </div>
  @endif

  <form method="POST" action="{{ url('/rab/'.$rab->id) }}" style="padding:0 24px 24px">
    @csrf @method('PUT')

    {{-- Info deal (read-only) --}}
    <div style="padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:6px;font-size:12px;margin-bottom:20px">
      <div style="display:flex;gap:24px;flex-wrap:wrap">
        <div><span style="color:var(--muted)">Nilai Proyek:</span>
          <strong id="di-nilai">Rp {{ number_format($rab->deal->nilai_proyek) }}</strong></div>
        <div><span style="color:var(--muted)">Sales:</span>
          <strong>{{ $rab->deal->sales?->name ?? '-' }}</strong></div>
      </div>
    </div>

    {{-- Pekerjaan --}}
    <div style="display:grid;gap:16px;margin-bottom:20px">
      <div>
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">
          Pekerjaan <span style="color:var(--err)">*</span>
        </label>
        <input type="text" name="pekerjaan" value="{{ old('pekerjaan', $rab->pekerjaan) }}" required
               style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface);box-sizing:border-box">
      </div>
      <div>
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">
          Item Pekerjaan <span style="color:var(--err)">*</span>
        </label>
        <textarea name="item_pekerjaan" required rows="3"
                  style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface);box-sizing:border-box;resize:vertical">{{ old('item_pekerjaan', $rab->item_pekerjaan) }}</textarea>
      </div>
      <div>
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">
          Detail Pekerjaan
        </label>
        <textarea name="detail_pekerjaan" rows="3"
                  style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface);box-sizing:border-box;resize:vertical">{{ old('detail_pekerjaan', $rab->detail_pekerjaan) }}</textarea>
      </div>
      <div>
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">
          Waktu Pengerjaan (hari) <span style="color:var(--err)">*</span>
        </label>
        <input type="number" name="waktu_pengerjaan" value="{{ old('waktu_pengerjaan', $rab->waktu_pengerjaan) }}"
               required min="1"
               style="width:160px;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface)">
      </div>
    </div>

    {{-- Biaya --}}
    <div style="padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:8px;margin-bottom:20px">
      <h4 style="margin:0 0 14px;font-size:13px;font-weight:600">Rincian Biaya</h4>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
        @foreach([
          ['cost_material',  'Biaya Material'],
          ['cost_labor',     'Biaya Tenaga Kerja'],
          ['cost_finishing', 'Biaya Finishing'],
          ['cost_other',     'Biaya Lain-lain'],
        ] as [$field, $label])
        <div>
          <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">{{ $label }}</label>
          <div style="display:flex;align-items:center;gap:4px">
            <span style="font-size:12px;color:var(--muted)">Rp</span>
            <input type="number" name="{{ $field }}" id="{{ $field }}"
                   value="{{ old($field, $rab->{$field}) }}"
                   min="0" step="1000"
                   oninput="hitungTotal()"
                   style="flex:1;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--bg)">
          </div>
        </div>
        @endforeach
      </div>
      <div style="margin-top:16px;padding-top:14px;border-top:2px solid var(--border);display:flex;align-items:center;justify-content:space-between">
        <span style="font-size:13px;font-weight:600">Total RAB</span>
        <div style="text-align:right">
          <div id="total-display" style="font-size:20px;font-weight:700;color:var(--accent)">Rp 0</div>
          <div id="selisih-display" style="font-size:11px;color:var(--muted);margin-top:2px"></div>
        </div>
      </div>
    </div>

    {{-- Status --}}
    <div style="margin-bottom:24px">
      <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">Status RAB</label>
      <select name="status" required
              style="width:200px;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface)">
        <option value="draft"    {{ old('status',$rab->status)==='draft'    ? 'selected' : '' }}>Draft</option>
        <option value="terkirim" {{ old('status',$rab->status)==='terkirim' ? 'selected' : '' }}>Terkirim ke Customer</option>
        <option value="acc"      {{ old('status',$rab->status)==='acc'      ? 'selected' : '' }}>ACC / Disetujui</option>
      </select>
    </div>

    <div style="display:flex;gap:10px">
      <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
      <a href="{{ url('/rab') }}" class="btn btn-secondary">Batal</a>
    </div>
  </form>
</div>

<script>
const nilaiProyek = {{ $rab->deal->nilai_proyek }};
function fmt(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }
function hitungTotal() {
  let total = 0;
  ['cost_material','cost_labor','cost_finishing','cost_other'].forEach(f => {
    total += parseInt(document.getElementById(f).value) || 0;
  });
  document.getElementById('total-display').textContent = fmt(total);
  const selisih = nilaiProyek - total;
  const el = document.getElementById('selisih-display');
  el.textContent = (selisih >= 0 ? '+' : '') + fmt(selisih) + ' dari nilai proyek';
  el.style.color = selisih >= 0 ? 'var(--ok)' : 'var(--err)';
}
hitungTotal();
</script>
@endsection
