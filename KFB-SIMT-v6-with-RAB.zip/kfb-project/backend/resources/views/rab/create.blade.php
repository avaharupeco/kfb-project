@extends('layouts.app')
@section('title','Buat RAB Baru')
@section('page-title','Buat RAB Baru')

@section('content')
<div class="card" style="max-width:860px;margin:0 auto">
  <div style="padding:20px 24px 0;border-bottom:1px solid var(--border);margin-bottom:20px">
    <h3 style="margin:0 0 4px;font-size:15px">Form Rencana Anggaran Biaya</h3>
    <p style="margin:0 0 16px;font-size:12px;color:var(--muted)">Isi semua kolom yang diperlukan. Total biaya RAB akan dihitung otomatis.</p>
  </div>

  @if($errors->any())
    <div class="alert alert-danger" style="margin:0 24px 16px;padding:10px 14px;background:#fee;border:1px solid var(--err);border-radius:6px;font-size:12px;color:var(--err)">
      <ul style="margin:0;padding-left:16px">
        @foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach
      </ul>
    </div>
  @endif

  <form method="POST" action="{{ url('/rab') }}" style="padding:0 24px 24px">
    @csrf

    {{-- ── BAGIAN 1: PILIH DEAL ─────────────────────────── --}}
    <div style="margin-bottom:20px">
      <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">
        Deal / Customer <span style="color:var(--err)">*</span>
      </label>
      <select name="deal_id" required
              style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface)"
              onchange="loadDealInfo(this)">
        <option value="">— Pilih Deal —</option>
        @foreach($deals as $d)
          <option value="{{ $d->id }}"
                  data-nilai="{{ $d->nilai_proyek }}"
                  data-sales="{{ $d->sales?->name ?? '-' }}"
                  data-item="{{ $d->item_pekerjaan }}"
                  data-detail="{{ $d->detail_pekerjaan }}"
                  data-jenis="{{ $d->jenis_furnitur }}"
                  {{ old('deal_id') == $d->id ? 'selected' : '' }}>
            {{ $d->customer->name }} ({{ $d->customer->kode }}) — {{ $d->jenis_furnitur }}
            — Rp {{ number_format($d->nilai_proyek) }}
          </option>
        @endforeach
      </select>
      {{-- Info deal yang dipilih --}}
      <div id="deal-info" style="display:none;margin-top:8px;padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:6px;font-size:12px">
        <div style="display:flex;gap:24px;flex-wrap:wrap">
          <div><span style="color:var(--muted)">Nilai Proyek:</span> <strong id="di-nilai">-</strong></div>
          <div><span style="color:var(--muted)">Sales:</span> <strong id="di-sales">-</strong></div>
        </div>
      </div>
    </div>

    {{-- ── BAGIAN 2: DETAIL PEKERJAAN ───────────────────── --}}
    <div style="display:grid;gap:16px;margin-bottom:20px">

      <div>
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">
          Pekerjaan <span style="color:var(--err)">*</span>
          <span style="color:var(--muted);font-weight:400">(nama/jenis furnitur yang dikerjakan)</span>
        </label>
        <input type="text" name="pekerjaan" value="{{ old('pekerjaan') }}" required
               placeholder="cth: Lemari Pakaian 3 Pintu, Kitchen Set, dll"
               style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface);box-sizing:border-box">
      </div>

      <div>
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">
          Item Pekerjaan <span style="color:var(--err)">*</span>
          <span style="color:var(--muted);font-weight:400">(daftar item yang dikerjakan)</span>
        </label>
        <textarea name="item_pekerjaan" required rows="3"
                  placeholder="cth: 1 unit lemari 3 pintu, 2 unit nakas, pemasangan dan finishing"
                  style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface);box-sizing:border-box;resize:vertical">{{ old('item_pekerjaan') }}</textarea>
      </div>

      <div>
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">
          Detail Pekerjaan
          <span style="color:var(--muted);font-weight:400">(spesifikasi teknis, material, ukuran)</span>
        </label>
        <textarea name="detail_pekerjaan" rows="3"
                  placeholder="cth: Material HPL Taco, ukuran 200x220cm, engsel softclose, rel laci full-extension"
                  style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface);box-sizing:border-box;resize:vertical">{{ old('detail_pekerjaan') }}</textarea>
      </div>

      <div>
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">
          Waktu Pengerjaan (hari) <span style="color:var(--err)">*</span>
        </label>
        <input type="number" name="waktu_pengerjaan" value="{{ old('waktu_pengerjaan', 14) }}"
               required min="1" max="365"
               style="width:160px;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface)">
      </div>
    </div>

    {{-- ── BAGIAN 3: BIAYA ──────────────────────────────── --}}
    <div style="padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:8px;margin-bottom:20px">
      <h4 style="margin:0 0 14px;font-size:13px;font-weight:600">Rincian Biaya</h4>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
        @foreach([
          ['cost_material',  'Biaya Material',   'HPL, plywood, hardware, dll'],
          ['cost_labor',     'Biaya Tenaga Kerja','Upah tukang, helper, supir'],
          ['cost_finishing', 'Biaya Finishing',  'Cat, dempul, PU, dll'],
          ['cost_other',     'Biaya Lain-lain',  'Ongkir, biaya tak terduga, dll'],
        ] as [$field, $label, $hint])
        <div>
          <label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px">
            {{ $label }}
            @if($field !== 'cost_other')<span style="color:var(--err)">*</span>@endif
          </label>
          <div style="font-size:11px;color:var(--muted);margin-bottom:6px">{{ $hint }}</div>
          <div style="display:flex;align-items:center;gap:4px">
            <span style="font-size:12px;color:var(--muted)">Rp</span>
            <input type="number" name="{{ $field }}" id="{{ $field }}"
                   value="{{ old($field, 0) }}"
                   @if($field !== 'cost_other') required @endif
                   min="0" step="1000"
                   oninput="hitungTotal()"
                   style="flex:1;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--bg)">
          </div>
        </div>
        @endforeach
      </div>

      {{-- TOTAL --}}
      <div style="margin-top:16px;padding-top:14px;border-top:2px solid var(--border);display:flex;align-items:center;justify-content:space-between">
        <span style="font-size:13px;font-weight:600">Total RAB</span>
        <div style="text-align:right">
          <div id="total-display" style="font-size:20px;font-weight:700;color:var(--accent)">Rp 0</div>
          <div id="selisih-display" style="font-size:11px;color:var(--muted);margin-top:2px"></div>
        </div>
      </div>
    </div>

    {{-- ── BAGIAN 4: STATUS ─────────────────────────────── --}}
    <div style="margin-bottom:24px">
      <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">
        Status RAB <span style="color:var(--err)">*</span>
      </label>
      <select name="status" required
              style="width:200px;padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:13px;background:var(--surface)">
        <option value="draft"    {{ old('status','draft')==='draft'    ? 'selected' : '' }}>Draft</option>
        <option value="terkirim" {{ old('status')==='terkirim' ? 'selected' : '' }}>Terkirim ke Customer</option>
        <option value="acc"      {{ old('status')==='acc'      ? 'selected' : '' }}>ACC / Disetujui</option>
      </select>
    </div>

    {{-- TOMBOL --}}
    <div style="display:flex;gap:10px">
      <button type="submit" class="btn btn-primary">Simpan RAB</button>
      <a href="{{ url('/rab') }}" class="btn btn-secondary">Batal</a>
    </div>
  </form>
</div>

<script>
function fmt(n) {
  return 'Rp ' + Number(n).toLocaleString('id-ID');
}

let nilaiProyek = 0;

function loadDealInfo(sel) {
  const opt = sel.options[sel.selectedIndex];
  if (!opt.value) {
    document.getElementById('deal-info').style.display = 'none';
    nilaiProyek = 0;
    hitungTotal();
    return;
  }
  nilaiProyek = parseInt(opt.dataset.nilai) || 0;
  document.getElementById('di-nilai').textContent = fmt(nilaiProyek);
  document.getElementById('di-sales').textContent = opt.dataset.sales;
  document.getElementById('deal-info').style.display = 'block';

  // Auto-isi item & detail dari deal jika kosong
  const item   = document.querySelector('[name=item_pekerjaan]');
  const detail = document.querySelector('[name=detail_pekerjaan]');
  const peker  = document.querySelector('[name=pekerjaan]');
  if (!peker.value)   peker.value   = opt.dataset.jenis;
  if (!item.value)    item.value    = opt.dataset.item;
  if (!detail.value)  detail.value  = opt.dataset.detail;

  hitungTotal();
}

function hitungTotal() {
  const fields = ['cost_material','cost_labor','cost_finishing','cost_other'];
  let total = 0;
  fields.forEach(f => {
    total += parseInt(document.getElementById(f).value) || 0;
  });
  document.getElementById('total-display').textContent = fmt(total);

  if (nilaiProyek > 0) {
    const selisih = nilaiProyek - total;
    const el = document.getElementById('selisih-display');
    el.textContent = (selisih >= 0 ? '+' : '') + fmt(selisih) + ' dari nilai proyek';
    el.style.color = selisih >= 0 ? 'var(--ok)' : 'var(--err)';
  } else {
    document.getElementById('selisih-display').textContent = '';
  }
}

hitungTotal();
</script>
@endsection
