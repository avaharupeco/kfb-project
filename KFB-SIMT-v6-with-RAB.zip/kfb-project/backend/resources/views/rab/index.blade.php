@extends('layouts.app')
@section('title','RAB — Rencana Anggaran Biaya')
@section('page-title','RAB — Rencana Anggaran Biaya')
@section('topbar-actions')
  @can_role(['admin','owner'])
    <a href="{{ url('/rab/create') }}" class="btn btn-primary btn-sm">+ Buat RAB Baru</a>
  @endcan_role
@endsection

@section('content')
@php
  $stClass  = ['draft'=>'badge-deal','terkirim'=>'badge-produksi','acc'=>'badge-selesai'];
  $stLabel  = ['draft'=>'Draft','terkirim'=>'Terkirim','acc'=>'ACC'];
@endphp

{{-- FILTER BAR --}}
<div class="filter-bar">
  <form method="GET" action="{{ url('/rab') }}" style="display:flex;gap:8px;flex:1;flex-wrap:wrap">
    <input class="search-input" name="search" value="{{ request('search') }}" placeholder="Cari nama customer / kode...">
    <a href="{{ url('/rab') }}"               class="chip {{ !request('status') ? 'active' : '' }}">Semua</a>
    @foreach(['draft','terkirim','acc'] as $s)
      <a href="{{ url('/rab?status='.$s.'&search='.request('search')) }}"
         class="chip {{ request('status')===$s ? 'active' : '' }}">{{ $stLabel[$s] }}</a>
    @endforeach
  </form>
</div>

{{-- TABEL RAB --}}
<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Customer</th>
          <th>Pekerjaan</th>
          <th>Item Pekerjaan</th>
          <th>Detail Pekerjaan</th>
          <th>Waktu (hari)</th>
          <th>Sales</th>
          <th>Nilai Proyek</th>
          <th>DEAL RAB</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        @forelse($rabs as $i => $r)
        <tr>
          {{-- No --}}
          <td style="font-size:11px;color:var(--muted)">{{ $rabs->firstItem() + $i }}</td>

          {{-- Customer --}}
          <td>
            <div class="td-main">{{ $r->deal->customer->name }}</div>
            <div class="td-sub">{{ $r->deal->customer->kode }}</div>
          </td>

          {{-- Pekerjaan --}}
          <td style="font-size:11px;max-width:160px">{{ $r->pekerjaan ?? $r->deal->jenis_furnitur }}</td>

          {{-- Item Pekerjaan --}}
          <td style="font-size:11px;max-width:180px">
            <span title="{{ $r->item_pekerjaan ?? $r->deal->item_pekerjaan }}">
              {{ \Illuminate\Support\Str::limit($r->item_pekerjaan ?? $r->deal->item_pekerjaan, 60) }}
            </span>
          </td>

          {{-- Detail Pekerjaan --}}
          <td style="font-size:11px;max-width:180px">
            <span title="{{ $r->detail_pekerjaan ?? $r->deal->detail_pekerjaan }}">
              {{ \Illuminate\Support\Str::limit($r->detail_pekerjaan ?? $r->deal->detail_pekerjaan, 50) ?? '-' }}
            </span>
          </td>

          {{-- Waktu Pengerjaan --}}
          <td style="text-align:center">
            <strong>{{ $r->waktu_pengerjaan }}</strong>
            <div class="td-sub">hari</div>
          </td>

          {{-- Sales --}}
          <td style="font-size:11px">{{ $r->deal->sales?->name ?? '-' }}</td>

          {{-- Nilai Proyek --}}
          <td><strong>Rp {{ number_format($r->deal->nilai_proyek) }}</strong></td>

          {{-- DEAL RAB (total biaya RAB vs nilai proyek) --}}
          <td>
            <strong>Rp {{ number_format($r->total) }}</strong>
            @php $selisih = $r->deal->nilai_proyek - $r->total; @endphp
            @if($r->total > 0)
              <div class="td-sub" style="color:{{ $selisih >= 0 ? 'var(--ok)' : 'var(--err)' }}">
                {{ $selisih >= 0 ? '+' : '' }}Rp {{ number_format($selisih) }}
              </div>
            @endif
          </td>

          {{-- Status --}}
          <td><span class="badge {{ $stClass[$r->status] }}">{{ $stLabel[$r->status] }}</span></td>

          {{-- Aksi --}}
          <td style="white-space:nowrap">
            <a href="{{ url('/rab/'.$r->id) }}"       class="btn btn-secondary btn-xs">Detail</a>
            <a href="{{ url('/rab/'.$r->id.'/edit') }}" class="btn btn-secondary btn-xs">Edit</a>
            <form method="POST" action="{{ url('/rab/'.$r->id) }}" style="display:inline"
                  onsubmit="return confirm('Hapus RAB ini?')">
              @csrf @method('DELETE')
              <button type="submit" class="btn btn-xs" style="background:var(--err);color:#fff">Hapus</button>
            </form>
          </td>
        </tr>
        @empty
        <tr><td colspan="11" class="empty-state">Belum ada RAB. Klik tombol <strong>+ Buat RAB Baru</strong> untuk memulai.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  <div>{{ $rabs->withQueryString()->links() }}</div>
</div>
@endsection
