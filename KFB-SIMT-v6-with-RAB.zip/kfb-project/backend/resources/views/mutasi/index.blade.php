@extends('layouts.app')
@section('title','Mutasi Rekening')
@section('page-title','Mutasi Rekening Bank')
@section('topbar-actions')
  @can_role(['admin','owner'])
  <button onclick="document.getElementById('modal-mutasi').style.display='flex'" class="btn btn-primary btn-sm">+ Catat Mutasi</button>
  @endcan_role
@endsection
@section('content')
<div class="metric-row col-3">
  <div class="metric"><div class="metric-label">Total Masuk</div><div class="metric-value ok">Rp {{ number_format($masuk) }}</div></div>
  <div class="metric"><div class="metric-label">Total Keluar</div><div class="metric-value err">Rp {{ number_format($keluar) }}</div></div>
  <div class="metric"><div class="metric-label">Saldo Rekening</div><div class="metric-value wood">Rp {{ number_format($saldo) }}</div></div>
</div>
<div class="filter-bar">
  <a href="{{ url('/mutasi') }}" class="chip {{ !request('type') ? 'active' : '' }}">Semua</a>
  <a href="{{ url('/mutasi?type=masuk') }}" class="chip {{ request('type')==='masuk' ? 'active' : '' }}">Masuk</a>
  <a href="{{ url('/mutasi?type=keluar') }}" class="chip {{ request('type')==='keluar' ? 'active' : '' }}">Keluar</a>
</div>
<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Tanggal</th><th>Keterangan</th><th>Kategori</th><th>No. Referensi</th><th>Jenis</th><th style="text-align:right">Jumlah</th></tr></thead>
      <tbody>
        @forelse($mutasi as $m)
        <tr>
          <td style="font-size:11px">{{ $m->tanggal->format('d M Y') }}</td>
          <td class="td-main">{{ $m->keterangan }}</td>
          <td style="font-size:11px;color:var(--muted)">{{ $m->kategori }}</td>
          <td style="font-size:10px;color:var(--hint)">{{ $m->no_referensi ?: '—' }}</td>
          <td><span class="badge badge-{{ $m->type }}">{{ $m->type==='masuk'?'Kredit':'Debit' }}</span></td>
          <td style="text-align:right;font-weight:700;font-size:13px;color:{{ $m->type==='masuk'?'var(--ok)':'var(--err)' }}">
            {{ $m->type==='masuk'?'+':'-' }} Rp {{ number_format($m->jumlah) }}
          </td>
        </tr>
        @empty
        <tr><td colspan="6" class="empty-state">Belum ada mutasi rekening</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  {{ $mutasi->links() }}
</div>
@endsection
@section('modals')
<div id="modal-mutasi" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:500;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:14px;padding:26px;width:480px;max-width:96vw;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
      <h2 style="font-size:15px;font-weight:700">Catat Mutasi Rekening</h2>
      <button onclick="document.getElementById('modal-mutasi').style.display='none'" style="background:var(--bg);border:none;width:28px;height:28px;border-radius:50%;cursor:pointer;font-size:14px">✕</button>
    </div>
    <form action="{{ url('/mutasi') }}" method="POST">
      @csrf
      <div class="form-row">
        <div class="form-group"><label class="form-label">Jenis</label><select class="form-control" name="type"><option value="masuk">Masuk / Kredit</option><option value="keluar">Keluar / Debit</option></select></div>
        <div class="form-group"><label class="form-label">Jumlah (Rp)</label><input class="form-control" type="number" name="jumlah" min="1" required placeholder="0"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Kategori</label><select class="form-control" name="kategori"><option>dp_pesanan</option><option>pelunasan</option><option>beli_material</option><option>gaji_tim</option><option>operasional</option><option>transfer</option></select></div>
        <div class="form-group"><label class="form-label">No. Referensi</label><input class="form-control" name="no_referensi" placeholder="No. bukti transfer (opsional)"></div>
      </div>
      <div class="form-group"><label class="form-label">Keterangan</label><input class="form-control" name="keterangan" placeholder="Detail transaksi..." required></div>
      <div class="form-group"><label class="form-label">Tanggal</label><input class="form-control" type="date" name="tanggal" value="{{ date('Y-m-d') }}" required></div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:11px">Simpan Mutasi</button>
    </form>
  </div>
</div>
@endsection
