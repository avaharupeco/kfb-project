@extends('layouts.app')
@section('title','Kebutuhan Bahan')
@section('page-title','Kebutuhan Bahan Produksi')
@section('topbar-actions')
  <button onclick="document.getElementById('modal-bahan').style.display='flex'" class="btn btn-primary btn-sm">+ Ajukan Bahan</button>
@endsection
@section('content')
<div class="filter-bar">
  <a href="{{ url('/bahan') }}" class="chip {{ !request('status') ? 'active' : '' }}">Semua</a>
  @foreach(['diajukan','approved','dibeli','ditolak'] as $s)
    <a href="{{ url('/bahan?status='.$s) }}" class="chip {{ request('status')===$s ? 'active' : '' }}">{{ ucfirst($s) }}</a>
  @endforeach
</div>
<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Proyek / Customer</th><th>Nama Bahan</th><th>Keinginan Customer</th><th>Qty</th><th>Harga/Sat</th><th>Total</th><th>Catatan Toko</th><th>Diajukan Oleh</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
        @forelse($bahan as $b)
        <tr>
          <td><div class="td-main">{{ $b->deal->customer->name }}</div><div class="td-sub">{{ Str::limit($b->deal->jenis_furnitur,24) }}</div></td>
          <td class="td-main">{{ $b->nama_bahan }}</td>
          <td style="font-size:10.5px;color:var(--hint);font-style:italic;max-width:160px">"{{ $b->keinginan_customer }}"</td>
          <td style="font-weight:600">{{ $b->qty }} {{ $b->satuan }}</td>
          <td>Rp {{ number_format($b->harga_satuan) }}</td>
          <td><strong>Rp {{ number_format($b->total_harga) }}</strong></td>
          <td style="font-size:10px;color:var(--hint)">{{ $b->catatan_toko ?: '—' }}</td>
          <td style="font-size:11px">{{ $b->requestedBy->name }}</td>
          <td><span class="badge badge-{{ $b->status }}">{{ ucfirst($b->status) }}</span></td>
          <td>
            @if($b->status === 'diajukan')
              @can_role(['admin','owner'])
                <div style="display:flex;gap:4px">
                  <form action="{{ url('/bahan/'.$b->id.'/approve') }}" method="POST">@csrf @method('PATCH')<button class="btn btn-success btn-xs">✓ Setujui</button></form>
                  <form action="{{ url('/bahan/'.$b->id.'/reject') }}" method="POST">@csrf @method('PATCH')<button class="btn btn-danger btn-xs">✗ Tolak</button></form>
                </div>
              @endcan_role
            @elseif($b->status === 'approved')
              @can_role(['produksi','admin'])
                <form action="{{ url('/bahan/'.$b->id.'/beli') }}" method="POST">@csrf @method('PATCH')<button class="btn btn-success btn-xs">Tandai Dibeli</button></form>
              @endcan_role
            @else
              <span style="font-size:10px;color:var(--muted)">—</span>
            @endif
          </td>
        </tr>
        @empty
        <tr><td colspan="10" class="empty-state">Belum ada pengajuan bahan</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  {{ $bahan->links() }}
</div>
@endsection
@section('modals')
<div id="modal-bahan" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:500;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:14px;padding:26px;width:540px;max-width:96vw;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
      <h2 style="font-size:15px;font-weight:700">Ajukan Kebutuhan Bahan</h2>
      <button onclick="document.getElementById('modal-bahan').style.display='none'" style="background:var(--bg);border:none;width:28px;height:28px;border-radius:50%;cursor:pointer;font-size:14px">✕</button>
    </div>
    <form action="{{ url('/bahan') }}" method="POST">
      @csrf
      <div class="form-group"><label class="form-label">Proyek / Order</label>
        <select class="form-control" name="deal_id" required>
          <option value="">-- Pilih Proyek --</option>
          @foreach(\App\Models\Deal::with('customer')->whereIn('status',['deal','produksi'])->get() as $d)
            <option value="{{ $d->id }}">{{ $d->customer->kode }} — {{ $d->customer->name }}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group"><label class="form-label">Bahan yang Diinginkan Customer</label>
        <textarea class="form-control" name="keinginan_customer" rows="2" placeholder="cth: HPL motif kayu natural warna coklat tua, finishing doff tidak mengkilap..."></textarea>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Nama Bahan</label><input class="form-control" id="bahan-qty" name="nama_bahan" placeholder="cth: HPL Natural Oak" required></div>
        <div class="form-group"><label class="form-label">Satuan</label><select class="form-control" name="satuan"><option>lembar</option><option>pcs</option><option>meter</option><option>kg</option><option>liter</option><option>set</option><option>roll</option></select></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Jumlah</label><input class="form-control" id="bahan-qty" name="qty" type="number" step="0.5" min="0.1" placeholder="0" required></div>
        <div class="form-group"><label class="form-label">Estimasi Harga/Satuan (Rp)</label><input class="form-control" id="bahan-harga" name="harga_satuan" type="number" min="0" placeholder="0" required></div>
      </div>
      <div class="form-group" style="background:var(--woodll);border:1px solid rgba(124,61,18,.15);padding:10px;border-radius:7px">
        <div style="font-size:11px;color:var(--muted)">Estimasi Total: <strong id="bahan-total-display">Rp 0</strong></div>
      </div>
      <div class="form-group"><label class="form-label">Catatan untuk Admin / Toko</label><input class="form-control" name="catatan_toko" placeholder="Toko tujuan, merk, kode warna, spesifikasi khusus..."></div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:11px">Kirim Pengajuan Bahan</button>
    </form>
  </div>
</div>
@endsection
