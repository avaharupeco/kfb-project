@extends('layouts.app')
@section('title','Absensi')
@section('page-title','Absensi Karyawan')
@section('topbar-actions')
  <button onclick="document.getElementById('modal-absen').style.display='flex'" class="btn btn-primary btn-sm">+ Input Absensi</button>
@endsection
@section('content')
@foreach($absensi->groupBy('tanggal') as $tgl => $rows)
<div class="card">
  <div class="card-header">
    <div><div class="card-title">{{ \Carbon\Carbon::parse($tgl)->translatedFormat('l, d F Y') }}</div>
      <div class="card-sub">{{ $rows->where('status','hadir')->count() }} hadir · {{ $rows->where('status','absen')->count() }} absen · {{ $rows->where('status','izin')->count() }} izin</div>
    </div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Nama Karyawan</th><th>Role</th><th>Status</th><th>Keterangan</th></tr></thead>
      <tbody>
        @foreach($rows as $a)
        <tr>
          <td class="td-main">{{ $a->user->name }}</td>
          <td style="font-size:11px;color:var(--muted)">{{ ucfirst($a->user->role) }}</td>
          <td><span class="badge badge-{{ $a->status }}">{{ ucfirst($a->status) }}</span></td>
          <td style="font-size:11px;color:var(--hint)">{{ $a->keterangan ?: '—' }}</td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>
@endforeach
@if($absensi->isEmpty())
  <div class="card"><div class="empty-state">Belum ada data absensi. Klik "Input Absensi" untuk mulai mencatat.</div></div>
@endif
{{ $absensi->links() }}
@endsection
@section('modals')
<div id="modal-absen" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:500;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:14px;padding:26px;width:560px;max-width:96vw;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
      <h2 style="font-size:15px;font-weight:700">Input Absensi Karyawan</h2>
      <button onclick="document.getElementById('modal-absen').style.display='none'" style="background:var(--bg);border:none;width:28px;height:28px;border-radius:50%;cursor:pointer;font-size:14px">✕</button>
    </div>
    <form action="{{ url('/absen') }}" method="POST">
      @csrf
      <div class="form-group"><label class="form-label">Tanggal</label><input class="form-control" type="date" name="tanggal" value="{{ date('Y-m-d') }}" required></div>
      @foreach($users as $u)
      <div style="display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid var(--line)">
        <div><div style="font-size:13px;font-weight:500">{{ $u->name }}</div><div style="font-size:11px;color:var(--muted)">{{ ucfirst($u->role) }}</div></div>
        <div style="display:flex;gap:8px;align-items:center">
          <input type="hidden" name="absensi[{{ $loop->index }}][user_id]" value="{{ $u->id }}">
          <select class="form-control" name="absensi[{{ $loop->index }}][status]" style="width:auto;padding:6px 10px">
            <option value="hadir">Hadir</option>
            <option value="absen">Absen</option>
            <option value="izin">Izin</option>
            <option value="sakit">Sakit</option>
          </select>
          <input class="form-control" name="absensi[{{ $loop->index }}][keterangan]" placeholder="Ket. (opsional)" style="width:140px;padding:6px 10px">
        </div>
      </div>
      @endforeach
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:11px;margin-top:14px">Simpan Absensi</button>
    </form>
  </div>
</div>
@endsection
