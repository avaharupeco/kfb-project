<?php
// routes/web.php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DealController;
use App\Http\Controllers\BahanController;
use App\Http\Controllers\JadwalController;
use App\Http\Controllers\AbsensiController;
use App\Http\Controllers\PettyCashController;
use App\Http\Controllers\MutasiController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\RabController;

// ── PUBLIC ──────────────────────────────────────────────────────
Route::get('/', fn() => redirect('/login'));
Route::get('/login',  [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout',[AuthController::class, 'logout'])->name('logout');
Route::get('/register',  [RegisterController::class, 'show'])->name('register');
Route::post('/register', [RegisterController::class, 'store']);

// Webhook WhatsApp via Fonnte (opsional, tidak perlu auth)
Route::post('/api/wa-order', function(\Illuminate\Http\Request $req) {
    $pesan = $req->input('message','');
    $dari  = $req->input('phone','');
    if (!str_starts_with(strtoupper(trim($pesan)), 'ORDER')) {
        return response()->json(['status'=>'ignored']);
    }
    // Parse format: "ORDER\nNama: ...\nHP: ...\nProduk: ...\nBudget: ..."
    $baris = collect(explode("\n",$pesan))->mapWithKeys(function($line){
        $parts = explode(':',$line,2);
        return count($parts)===2 ? [strtolower(trim($parts[0]))=>trim($parts[1])] : [];
    });
    $customer = \App\Models\Customer::firstOrCreate(
        ['phone' => $dari],
        ['kode'=>'KFB-WA-'.time(),'name'=>$baris->get('nama','Customer WA'),'source'=>'whatsapp']
    );
    \App\Models\Deal::create([
        'customer_id'    => $customer->id,
        'jenis_furnitur' => $baris->get('produk','Belum ditentukan'),
        'jenis_deal'     => 'DP',
        'nilai_proyek'   => 0,'dp_amount'=>0,
        'status'         => 'deal',
        'tgl_persetujuan'=> now()->toDateString(),
        'garansi_hari'   => 30,
        'catatan'        => 'Order via WhatsApp. Budget: '.$baris->get('budget','-'),
    ]);
    return response()->json(['status'=>'success','customer'=>$customer->name]);
});

// ── PROTECTED ───────────────────────────────────────────────────
Route::middleware('auth')->group(function () {

    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // ── Owner: pantau, laporan, analitik ─────────────────────
    Route::middleware('role:owner,admin')->group(function () {
        Route::get('/mutasi',        [MutasiController::class, 'index']);
        Route::post('/mutasi',       [MutasiController::class, 'store']);
    });

    // ── Sales: input deal, garansi ────────────────────────────
    Route::middleware('role:owner,manager,sales,admin')->group(function () {
        Route::get('/deals',                          [DealController::class, 'index']);
        Route::get('/deals/create',                   [DealController::class, 'create']);
        Route::post('/deals',                         [DealController::class, 'store']);
        Route::get('/deals/{deal}',                   [DealController::class, 'show']);
        Route::get('/deals/{deal}/edit',              [DealController::class, 'edit']);
        Route::put('/deals/{deal}',                   [DealController::class, 'update']);
        Route::post('/deals/{deal}/bayar',            [DealController::class, 'confirmPembayaran']);
    });

    // ── Admin: database, absensi, petty cash, mutasi, bahan ──
    Route::middleware('role:owner,admin')->group(function () {
        Route::get('/absen',             [AbsensiController::class, 'index']);
        Route::post('/absen',            [AbsensiController::class, 'store']);
        Route::get('/petty',             [PettyCashController::class, 'index']);
        Route::post('/petty',            [PettyCashController::class, 'store']);
        Route::patch('/bahan/{bahan}/approve', [BahanController::class, 'approve']);
        Route::patch('/bahan/{bahan}/reject',  [BahanController::class, 'reject']);

        // RAB
        Route::get('/rab',               [RabController::class, 'index']);
        Route::get('/rab/create',        [RabController::class, 'create']);
        Route::post('/rab',              [RabController::class, 'store']);
        Route::get('/rab/{rab}',         [RabController::class, 'show']);
        Route::get('/rab/{rab}/edit',    [RabController::class, 'edit']);
        Route::put('/rab/{rab}',         [RabController::class, 'update']);
        Route::delete('/rab/{rab}',      [RabController::class, 'destroy']);
    });

    // ── Tim Produksi: bahan, jadwal, kanban ──────────────────
    Route::middleware('role:owner,admin,produksi')->group(function () {
        Route::get('/bahan',             [BahanController::class, 'index']);
        Route::post('/bahan',            [BahanController::class, 'store']);
        Route::patch('/bahan/{bahan}/beli',    [BahanController::class, 'markBeli']);
        Route::get('/jadwal',            [JadwalController::class, 'index']);
        Route::post('/jadwal',           [JadwalController::class, 'store']);
        Route::patch('/jadwal/{jadwal}/selesai', [JadwalController::class, 'selesai']);
    });

});
