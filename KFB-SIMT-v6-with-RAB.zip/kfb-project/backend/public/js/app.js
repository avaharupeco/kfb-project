/**
 * KFB SIMT — app.js
 * Kurnia Furniture Bogor · Sistem Informasi Manajemen
 * Vanilla JS — tidak butuh Node.js / npm untuk jalankan
 */

// ── CSRF untuk fetch/axios ────────────────────────────────────
const CSRF = document.querySelector('meta[name="csrf-token"]')?.content || '';

// ── KONFIRMASI DELETE ─────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {

  // Tombol konfirmasi sebelum submit form hapus
  document.querySelectorAll('[data-confirm]').forEach(btn => {
    btn.addEventListener('click', e => {
      const pesan = btn.dataset.confirm || 'Yakin ingin melanjutkan?';
      if (!confirm(pesan)) e.preventDefault();
    });
  });

  // Auto-dismiss alert setelah 4 detik
  document.querySelectorAll('.alert').forEach(el => {
    setTimeout(() => {
      el.style.transition = 'opacity .4s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 400);
    }, 4000);
  });

  // Aktivasi tab / chip filter tanpa reload (untuk tabel client-side)
  document.querySelectorAll('[data-filter-target]').forEach(chip => {
    chip.addEventListener('click', () => {
      const target   = chip.dataset.filterTarget;
      const val      = chip.dataset.filterVal;
      const col      = chip.dataset.filterCol;

      // toggle active
      document.querySelectorAll(`[data-filter-target="${target}"]`)
        .forEach(c => c.classList.remove('active'));
      chip.classList.add('active');

      // filter baris tabel
      document.querySelectorAll(`#${target} tbody tr`).forEach(tr => {
        if (!val || val === 'semua') {
          tr.style.display = '';
        } else {
          const cell = tr.querySelector(`[data-col="${col}"]`);
          tr.style.display = cell?.textContent.trim() === val ? '' : 'none';
        }
      });
    });
  });

  // Search realtime pada tabel
  document.querySelectorAll('[data-search-table]').forEach(input => {
    input.addEventListener('input', () => {
      const q    = input.value.toLowerCase();
      const tid  = input.dataset.searchTable;
      document.querySelectorAll(`#${tid} tbody tr`).forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  });

  // Hitung total RAB secara realtime
  const rabInputs = document.querySelectorAll('.rab-cost');
  if (rabInputs.length) {
    const updateTotal = () => {
      let total = 0;
      rabInputs.forEach(inp => total += parseInt(inp.value) || 0);
      const display = document.getElementById('rab-total');
      if (display) display.textContent = 'Rp ' + total.toLocaleString('id-ID');
    };
    rabInputs.forEach(inp => inp.addEventListener('input', updateTotal));
    updateTotal();
  }

  // Auto-hitung total bahan: qty × harga
  const bahanQty   = document.getElementById('bahan-qty');
  const bahanHarga = document.getElementById('bahan-harga');
  const bahanTotal = document.getElementById('bahan-total-display');
  if (bahanQty && bahanHarga && bahanTotal) {
    const hitungBahan = () => {
      const t = (parseFloat(bahanQty.value)||0) * (parseInt(bahanHarga.value)||0);
      bahanTotal.textContent = 'Rp ' + t.toLocaleString('id-ID');
    };
    bahanQty.addEventListener('input', hitungBahan);
    bahanHarga.addEventListener('input', hitungBahan);
  }

  // Format angka input saat user ketik (rupiah)
  document.querySelectorAll('[data-currency]').forEach(inp => {
    inp.addEventListener('blur', () => {
      const num = parseInt(inp.value.replace(/\D/g, '')) || 0;
      // nilai tetap angka biasa untuk form submit
      inp.value = num;
    });
  });

  // Sidebar active state berdasarkan URL
  const path = window.location.pathname;
  document.querySelectorAll('.nav-item').forEach(a => {
    if (a.getAttribute('href') && path.startsWith(a.getAttribute('href'))) {
      a.classList.add('active');
    }
  });

  // Keyboard shortcut: Ctrl+K → fokus ke search input
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      document.querySelector('.search-input')?.focus();
    }
  });

});

// ── HELPER: format rupiah ─────────────────────────────────────
function formatRupiah(n) {
  if (!n) return 'Rp 0';
  if (n >= 1_000_000) return 'Rp ' + (n / 1_000_000).toFixed(1).replace('.0','') + ' jt';
  if (n >= 1_000)     return 'Rp ' + (n / 1_000).toFixed(0) + ' rb';
  return 'Rp ' + n.toLocaleString('id-ID');
}

// ── KONFIRMASI PEMBAYARAN (inline preview) ────────────────────
function updatePembayaran(nilaiProyek, dpSudah) {
  const inputJumlah = document.getElementById('jumlah-bayar');
  const preview     = document.getElementById('sisa-preview');
  if (!inputJumlah || !preview) return;

  inputJumlah.addEventListener('input', () => {
    const masuk = parseInt(inputJumlah.value) || 0;
    const sisa  = nilaiProyek - dpSudah - masuk;
    preview.textContent = sisa <= 0
      ? '✓ Proyek akan berstatus LUNAS'
      : 'Sisa setelah pembayaran: Rp ' + sisa.toLocaleString('id-ID');
    preview.style.color = sisa <= 0 ? 'var(--ok)' : 'var(--muted)';
  });
}
