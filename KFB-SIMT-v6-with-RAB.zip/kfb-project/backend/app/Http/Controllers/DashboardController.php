<?php
namespace App\Http\Controllers;

use App\Models\Deal;
use App\Models\Customer;
use App\Models\Bahan;
use App\Models\JadwalPemasangan;
use App\Models\Absensi;
use App\Models\PettyCash;
use App\Models\MutasiRekening;
use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $role = auth()->user()->role;

        return match($role) {
            'owner'    => $this->ownerDash(),
            'manager'  => $this->managerDash(),
            'sales'    => $this->salesDash(),
            'admin'    => $this->adminDash(),
            'produksi' => $this->produksiDash(),
        };
    }

    private function ownerDash()
    {
        $deals    = Deal::with('customer')->get();
        $mutasi   = MutasiRekening::latest('tanggal')->limit(10)->get();
        $totalNilai = $deals->sum('nilai_proyek');
        $totalDP    = $deals->sum('dp_amount');
        $saldoMutasi = MutasiRekening::where('type','masuk')->sum('jumlah')
                     - MutasiRekening::where('type','keluar')->sum('jumlah');
        $omzetPerStatus = $deals->groupBy('status')->map(fn($g)=>$g->sum('nilai_proyek'));

        return view('dashboard.owner', compact(
            'deals','mutasi','totalNilai','totalDP','saldoMutasi','omzetPerStatus'
        ));
    }

    private function managerDash()
    {
        $deals = Deal::with(['customer','sales'])->get();
        $rabData = $deals->map(fn($d)=>[
            'deal'      => $d,
            'material'  => round($d->nilai_proyek * 0.40),
            'labor'     => round($d->nilai_proyek * 0.27),
            'finishing' => round($d->nilai_proyek * 0.18),
            'other'     => round($d->nilai_proyek * 0.15),
        ]);
        $staffGaji = [
            ['nama'=>'Pak Heru Santoso',  'role'=>'Tukang Senior',     'order'=>3,'base'=>600000,'bonus'=>0],
            ['nama'=>'Pak Dedi Firmansyah','role'=>'Tukang',            'order'=>2,'base'=>600000,'bonus'=>0],
            ['nama'=>'Mas Rizki Andriyanto','role'=>'Drafter',          'order'=>3,'base'=>500000,'bonus'=>150000],
            ['nama'=>'Pak Agus Waluyo',   'role'=>'Kepala Tim Produksi','order'=>4,'base'=>800000,'bonus'=>320000],
            ['nama'=>'Mas Budi Setiawan', 'role'=>'Finishing',          'order'=>2,'base'=>550000,'bonus'=>0],
        ];
        return view('dashboard.manager', compact('deals','rabData','staffGaji'));
    }

    private function salesDash()
    {
        $deals = Deal::with('customer')->orderBy('created_at','desc')->get();
        $today = now();
        $garansiData = $deals->map(function($d) use ($today) {
            $akhir = \Carbon\Carbon::parse($d->tgl_persetujuan)->addDays($d->garansi_hari);
            return [
                'deal'  => $d,
                'akhir' => $akhir->format('d/m/Y'),
                'sisa'  => max(0, $today->diffInDays($akhir, false)),
                'aktif' => $akhir->isFuture(),
            ];
        });
        return view('dashboard.sales', compact('deals','garansiData'));
    }

    private function adminDash()
    {
        $deals         = Deal::with(['customer','sales','manager'])->get();
        $bahanPending  = Bahan::where('status','diajukan')->with('deal.customer')->get();
        $absenHariIni  = Absensi::where('tanggal', today())->with('user')->get();
        $pettySaldo    = PettyCash::where('type','masuk')->sum('jumlah')
                       - PettyCash::where('type','keluar')->sum('jumlah');
        $mutasi        = MutasiRekening::latest('tanggal')->limit(10)->with('deal.customer')->get();
        $pettyAll      = PettyCash::latest('tanggal')->with('inputBy')->get();
        $saldoMutasi   = MutasiRekening::where('type','masuk')->sum('jumlah')
                       - MutasiRekening::where('type','keluar')->sum('jumlah');

        return view('dashboard.admin', compact(
            'deals','bahanPending','absenHariIni','pettySaldo',
            'mutasi','pettyAll','saldoMutasi'
        ));
    }

    private function produksiDash()
    {
        $deals          = Deal::with('customer')->get();
        $aktif          = $deals->whereIn('status',['deal','produksi','pemasangan']);
        $kanbanStages   = ['deal','produksi','pemasangan','selesai'];
        $kanban         = [];
        foreach ($kanbanStages as $s) {
            $kanban[$s] = $deals->where('status',$s)->values();
        }
        $bahan          = Bahan::with('deal.customer')->orderBy('created_at','desc')->get();
        $jadwal         = JadwalPemasangan::with('deal.customer')->orderBy('tgl_pasang')->get();

        return view('dashboard.produksi', compact('aktif','kanban','bahan','jadwal'));
    }
}
