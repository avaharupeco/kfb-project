<?php
namespace App\Http\Controllers;

use App\Models\PettyCash;
use Illuminate\Http\Request;

class PettyCashController extends Controller
{
    public function index()
    {
        $petty  = PettyCash::with(['inputBy','deal.customer'])->latest('tanggal')->paginate(25);
        $masuk  = PettyCash::where('type','masuk')->sum('jumlah');
        $keluar = PettyCash::where('type','keluar')->sum('jumlah');
        $saldo  = $masuk - $keluar;
        return view('petty.index', compact('petty','masuk','keluar','saldo'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'type'       => 'required|in:masuk,keluar',
            'kategori'   => 'required|string|max:60',
            'jumlah'     => 'required|integer|min:1',
            'keterangan' => 'nullable|string',
            'tanggal'    => 'required|date',
            'deal_id'    => 'nullable|exists:deals,id',
        ]);
        $data['input_by'] = auth()->id();
        PettyCash::create($data);
        return back()->with('success', 'Transaksi petty cash berhasil dicatat.');
    }
}
