<?php
namespace App\Http\Controllers;

use App\Models\JadwalPemasangan;
use App\Models\Deal;
use Illuminate\Http\Request;

class JadwalController extends Controller
{
    public function index()
    {
        $jadwal = JadwalPemasangan::with('deal.customer')->orderBy('tgl_pasang')->paginate(20);
        $deals  = Deal::with('customer')->whereIn('status',['produksi','pemasangan'])->get();
        return view('jadwal.index', compact('jadwal','deals'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'deal_id'         => 'required|exists:deals,id',
            'tgl_pasang'      => 'required|date',
            'jam_mulai'       => 'required',
            'tim_pemasangan'  => 'required|string',
            'alamat_lokasi'   => 'required|string',
            'catatan_teknis'  => 'nullable|string',
        ]);
        $data['status'] = 'dijadwalkan';
        JadwalPemasangan::create($data);

        // Update status deal ke pemasangan
        Deal::find($data['deal_id'])->update(['status'=>'pemasangan']);

        return back()->with('success', 'Jadwal pemasangan berhasil dibuat. Status proyek diupdate ke Pemasangan.');
    }

    public function selesai(JadwalPemasangan $jadwal)
    {
        $jadwal->selesai(); // method di model: update status + aktifkan garansi
        return back()->with('success', "Pemasangan selesai! Garansi {$jadwal->deal->garansi_hari} hari aktif.");
    }
}
