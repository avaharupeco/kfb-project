<?php
namespace App\Http\Controllers;

use App\Models\Bahan;
use App\Models\Deal;
use App\Models\PettyCash;
use Illuminate\Http\Request;

class BahanController extends Controller
{
    public function index()
    {
        $bahan = Bahan::with(['deal.customer','requestedBy','approvedBy'])
            ->latest()->paginate(20);
        return view('bahan.index', compact('bahan'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'deal_id'            => 'required|exists:deals,id',
            'nama_bahan'         => 'required|string|max:200',
            'keinginan_customer' => 'nullable|string',
            'qty'                => 'required|numeric|min:0.1',
            'satuan'             => 'required|string|max:20',
            'harga_satuan'       => 'required|integer|min:0',
            'catatan_toko'       => 'nullable|string',
        ]);

        $data['total_harga']   = (int)($data['qty'] * $data['harga_satuan']);
        $data['requested_by']  = auth()->id();
        $data['status']        = 'diajukan';

        Bahan::create($data);

        return back()->with('success', 'Pengajuan bahan berhasil dikirim. Menunggu persetujuan admin.');
    }

    public function approve(Bahan $bahan)
    {
        $bahan->update(['status'=>'approved','approved_by'=>auth()->id()]);
        return back()->with('success', "Bahan '{$bahan->nama_bahan}' disetujui. Tim produksi bisa mulai membeli.");
    }

    public function reject(Bahan $bahan)
    {
        $bahan->update(['status'=>'ditolak']);
        return back()->with('success', "Pengajuan '{$bahan->nama_bahan}' ditolak.");
    }

    public function markBeli(Request $request, Bahan $bahan)
    {
        $bahan->update(['status'=>'dibeli','struk_url'=>$request->struk_url]);

        // Auto-catat ke petty cash sebagai pengeluaran beli bahan
        PettyCash::create([
            'input_by'   => auth()->id(),
            'deal_id'    => $bahan->deal_id,
            'type'       => 'keluar',
            'kategori'   => 'Beli bahan produksi',
            'jumlah'     => $bahan->total_harga,
            'keterangan' => "Beli {$bahan->nama_bahan} untuk " . optional($bahan->deal->customer)->name,
            'tanggal'    => now()->toDateString(),
        ]);

        return back()->with('success', 'Pembelian dicatat. Pengeluaran otomatis masuk ke Petty Cash.');
    }
}
