<?php
namespace App\Http\Controllers;

use App\Models\MutasiRekening;
use Illuminate\Http\Request;

class MutasiController extends Controller
{
    public function index(Request $request)
    {
        $mutasi = MutasiRekening::with(['deal.customer','inputBy'])
            ->when($request->type, fn($q) => $q->where('type', $request->type))
            ->when($request->bulan, function ($q) use ($request) {
                [$y,$m] = explode('-', $request->bulan);
                $q->whereYear('tanggal',$y)->whereMonth('tanggal',$m);
            })
            ->latest('tanggal')
            ->paginate(25);

        $masuk  = MutasiRekening::where('type','masuk')->sum('jumlah');
        $keluar = MutasiRekening::where('type','keluar')->sum('jumlah');
        $saldo  = $masuk - $keluar;

        return view('mutasi.index', compact('mutasi','masuk','keluar','saldo'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'type'         => 'required|in:masuk,keluar',
            'kategori'     => 'required|string|max:60',
            'jumlah'       => 'required|integer|min:1',
            'keterangan'   => 'nullable|string',
            'no_referensi' => 'nullable|string',
            'tanggal'      => 'required|date',
            'deal_id'      => 'nullable|exists:deals,id',
        ]);
        $data['input_by'] = auth()->id();
        MutasiRekening::create($data);
        return back()->with('success', 'Mutasi rekening berhasil dicatat.');
    }
}
