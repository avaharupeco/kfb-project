<?php
namespace App\Http\Controllers;

use App\Models\Deal;
use App\Models\Customer;
use App\Models\MutasiRekening;
use Illuminate\Http\Request;

class DealController extends Controller
{
    public function index(Request $request)
    {
        $deals = Deal::with(['customer','sales','manager'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->search, function ($q) use ($request) {
                $q->whereHas('customer', fn($c) =>
                    $c->where('name','like',"%{$request->search}%")
                      ->orWhere('kode','like',"%{$request->search}%")
                );
            })
            ->latest()
            ->paginate(20);

        return view('deals.index', compact('deals'));
    }

    public function create()
    {
        $customers = Customer::orderBy('name')->get();
        $managers  = \App\Models\User::where('role','manager')->get();
        return view('deals.create', compact('customers','managers'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'customer_id'      => 'required|exists:customers,id',
            'jenis_furnitur'   => 'required|string|max:250',
            'item_pekerjaan'   => 'nullable|string',
            'detail_pekerjaan' => 'nullable|string',
            'jenis_deal'       => 'required|in:FP,DP',
            'nilai_proyek'     => 'required|integer|min:0',
            'dp_amount'        => 'required|integer|min:0',
            'manager_id'       => 'required|exists:users,id',
            'tgl_persetujuan'  => 'required|date',
            'garansi_hari'     => 'required|integer|in:30,60,90',
            'catatan'          => 'nullable|string',
        ]);

        $data['sales_id'] = auth()->id();
        $data['status']   = 'deal';

        // Jika FP, dp = nilai proyek
        if ($data['jenis_deal'] === 'FP') {
            $data['dp_amount'] = $data['nilai_proyek'];
        }

        $deal = Deal::create($data);

        // Auto-catat DP ke mutasi rekening jika ada dp
        if ($data['dp_amount'] > 0) {
            MutasiRekening::create([
                'deal_id'    => $deal->id,
                'input_by'   => auth()->id(),
                'type'       => 'masuk',
                'kategori'   => 'dp_pesanan',
                'jumlah'     => $data['dp_amount'],
                'keterangan' => "DP {$deal->jenis_deal} — {$deal->customer->name} ({$deal->customer->kode})",
                'tanggal'    => $data['tgl_persetujuan'],
            ]);
        }

        return redirect('/deals')->with('success', "Deal {$deal->customer->name} berhasil disimpan.");
    }

    public function show(Deal $deal)
    {
        $deal->load(['customer','sales','manager','rab','bahan','jadwal','mutasi']);
        return view('deals.show', compact('deal'));
    }

    public function edit(Deal $deal)
    {
        $customers = Customer::orderBy('name')->get();
        $managers  = \App\Models\User::where('role','manager')->get();
        return view('deals.edit', compact('deal','customers','managers'));
    }

    public function update(Request $request, Deal $deal)
    {
        $data = $request->validate([
            'jenis_furnitur'   => 'required|string|max:250',
            'item_pekerjaan'   => 'nullable|string',
            'detail_pekerjaan' => 'nullable|string',
            'jenis_deal'       => 'required|in:FP,DP',
            'nilai_proyek'     => 'required|integer|min:0',
            'dp_amount'        => 'required|integer|min:0',
            'status'           => 'required|in:deal,produksi,pemasangan,selesai',
            'garansi_hari'     => 'required|integer',
            'catatan'          => 'nullable|string',
        ]);

        $deal->update($data);

        return redirect("/deals/{$deal->id}")->with('success', 'Data deal diperbarui.');
    }

    public function confirmPembayaran(Request $request, Deal $deal)
    {
        $data = $request->validate([
            'jumlah'      => 'required|integer|min:1',
            'keterangan'  => 'nullable|string',
            'no_referensi'=> 'nullable|string',
        ]);

        $deal->update(['dp_amount' => $deal->dp_amount + $data['jumlah']]);

        MutasiRekening::create([
            'deal_id'      => $deal->id,
            'input_by'     => auth()->id(),
            'type'         => 'masuk',
            'kategori'     => $deal->dp_amount >= $deal->nilai_proyek ? 'pelunasan' : 'pembayaran',
            'jumlah'       => $data['jumlah'],
            'keterangan'   => $data['keterangan'] ?? "Pembayaran dari {$deal->customer->name}",
            'no_referensi' => $data['no_referensi'] ?? null,
            'tanggal'      => now()->toDateString(),
        ]);

        return back()->with('success', 'Pembayaran dikonfirmasi dan dicatat ke mutasi rekening.');
    }
}
