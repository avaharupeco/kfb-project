<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller {
    public function showLogin() {
        if (Auth::check()) return redirect('/dashboard');
        return view('auth.login');
    }
    public function login(Request $request) {
        $creds = $request->validate(['email'=>'required|email','password'=>'required']);
        if (!Auth::attempt($creds, $request->boolean('remember'))) {
            return back()->withErrors(['email'=>'Email atau password tidak sesuai.'])->onlyInput('email');
        }
        $request->session()->regenerate();
        return redirect()->intended('/dashboard');
    }
    public function logout(Request $request) {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }
}
