<?php
namespace App\Http\Controllers;

use App\Models\Absensi;
use App\Models\User;
use Illuminate\Http\Request;

class AbsensiController extends Controller
{
    public function index()
    {
        $absensi = Absensi::with('user')
            ->orderBy('tanggal','desc')
            ->paginate(50);

        $summary = Absensi::where('tanggal', today())
            ->with('user')
            ->get()
            ->groupBy('status');

        $users = User::where('is_active', true)->get();

        return view('absen.index', compact('absensi','summary','users'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'tanggal'     => 'required|date',
            'absensi'     => 'required|array',
            'absensi.*.user_id' => 'required|exists:users,id',
            'absensi.*.status'  => 'required|in:hadir,absen,izin,sakit',
        ]);

        foreach ($request->absensi as $row) {
            Absensi::updateOrCreate(
                ['user_id' => $row['user_id'], 'tanggal' => $request->tanggal],
                ['status'  => $row['status'], 'keterangan'=>$row['keterangan']??null, 'input_by'=>auth()->id()]
            );
        }

        return back()->with('success', "Absensi tanggal {$request->tanggal} berhasil disimpan.");
    }
}
