<?php
namespace App\Http\Controllers;

use App\Models\Rab;
use App\Models\Deal;
use App\Models\User;
use Illuminate\Http\Request;

class RabController extends Controller
{
    /**
     * Daftar semua RAB — hanya admin/owner
     */
    public function index(Request $request)
    {
        $rabs = Rab::with(['deal.customer', 'deal.sales'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->search, function ($q) use ($request) {
                $q->whereHas('deal.customer', fn($c) =>
                    $c->where('name', 'like', "%{$request->search}%")
                      ->orWhere('kode', 'like', "%{$request->search}%")
                );
            })
            ->latest()
            ->paginate(20);

        return view('rab.index', compact('rabs'));
    }

    /**
     * Form buat RAB baru — pilih deal yang belum punya RAB
     */
    public function create()
    {
        // Hanya deal yang belum punya RAB
        $deals = Deal::with(['customer', 'sales'])
            ->whereDoesntHave('rab')
            ->whereIn('status', ['deal', 'produksi', 'pemasangan'])
            ->orderBy('tgl_persetujuan', 'desc')
            ->get();

        return view('rab.create', compact('deals'));
    }

    /**
     * Simpan RAB baru
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'deal_id'          => 'required|exists:deals,id|unique:rabs,deal_id',
            'pekerjaan'        => 'required|string|max:500',
            'item_pekerjaan'   => 'required|string|max:1000',
            'detail_pekerjaan' => 'nullable|string',
            'waktu_pengerjaan' => 'required|integer|min:1',
            'cost_material'    => 'required|integer|min:0',
            'cost_labor'       => 'required|integer|min:0',
            'cost_finishing'   => 'required|integer|min:0',
            'cost_other'       => 'nullable|integer|min:0',
            'status'           => 'required|in:draft,terkirim,acc',
        ]);

        $data['cost_other'] = $data['cost_other'] ?? 0;
        $data['total']      = $data['cost_material'] + $data['cost_labor']
                            + $data['cost_finishing'] + $data['cost_other'];

        Rab::create($data);

        return redirect('/rab')->with('success', 'RAB berhasil dibuat.');
    }

    /**
     * Tampilkan detail RAB
     */
    public function show(Rab $rab)
    {
        $rab->load(['deal.customer', 'deal.sales', 'deal.manager']);
        return view('rab.show', compact('rab'));
    }

    /**
     * Form edit RAB
     */
    public function edit(Rab $rab)
    {
        $rab->load(['deal.customer', 'deal.sales']);
        return view('rab.edit', compact('rab'));
    }

    /**
     * Update RAB
     */
    public function update(Request $request, Rab $rab)
    {
        $data = $request->validate([
            'pekerjaan'        => 'required|string|max:500',
            'item_pekerjaan'   => 'required|string|max:1000',
            'detail_pekerjaan' => 'nullable|string',
            'waktu_pengerjaan' => 'required|integer|min:1',
            'cost_material'    => 'required|integer|min:0',
            'cost_labor'       => 'required|integer|min:0',
            'cost_finishing'   => 'required|integer|min:0',
            'cost_other'       => 'nullable|integer|min:0',
            'status'           => 'required|in:draft,terkirim,acc',
        ]);

        $data['cost_other'] = $data['cost_other'] ?? 0;
        $data['total']      = $data['cost_material'] + $data['cost_labor']
                            + $data['cost_finishing'] + $data['cost_other'];

        $rab->update($data);

        return redirect('/rab')->with('success', 'RAB berhasil diperbarui.');
    }

    /**
     * Hapus RAB
     */
    public function destroy(Rab $rab)
    {
        $rab->delete();
        return redirect('/rab')->with('success', 'RAB berhasil dihapus.');
    }
}
