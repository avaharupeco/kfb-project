<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        // @can_role(['owner','admin']) ... @endcan_role
        Blade::directive('can_role', function ($expression) {
            return "<?php if(auth()->check() && in_array(auth()->user()->role, {$expression})): ?>";
        });

        Blade::directive('endcan_role', function () {
            return "<?php endif; ?>";
        });
    }
}
