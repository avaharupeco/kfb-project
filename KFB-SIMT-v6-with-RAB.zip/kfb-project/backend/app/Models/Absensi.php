<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Absensi extends Model {
    protected $table    = 'absensi';
    protected $fillable = ['user_id','tanggal','status','keterangan','input_by'];
    protected $casts    = ['tanggal'=>'date'];
    public function user()    { return $this->belongsTo(User::class); }
    public function inputBy() { return $this->belongsTo(User::class,'input_by'); }
}
