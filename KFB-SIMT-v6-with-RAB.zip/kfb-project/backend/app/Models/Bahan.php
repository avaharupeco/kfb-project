<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Bahan extends Model {
    protected $table    = 'bahan';
    protected $fillable = ['deal_id','requested_by','approved_by','nama_bahan','keinginan_customer','qty','satuan','harga_satuan','total_harga','catatan_toko','status','struk_url'];
    protected $casts    = ['qty'=>'float','harga_satuan'=>'integer','total_harga'=>'integer'];
    public function deal()        { return $this->belongsTo(Deal::class); }
    public function requestedBy() { return $this->belongsTo(User::class,'requested_by'); }
    public function approvedBy()  { return $this->belongsTo(User::class,'approved_by'); }
}
