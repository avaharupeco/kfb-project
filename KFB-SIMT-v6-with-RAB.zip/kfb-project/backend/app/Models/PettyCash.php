<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PettyCash extends Model {
    protected $table    = 'petty_cash';
    protected $fillable = ['input_by','deal_id','type','kategori','jumlah','keterangan','tanggal'];
    protected $casts    = ['jumlah'=>'integer','tanggal'=>'date'];
    public function inputBy() { return $this->belongsTo(User::class,'input_by'); }
    public function deal()    { return $this->belongsTo(Deal::class); }
}
