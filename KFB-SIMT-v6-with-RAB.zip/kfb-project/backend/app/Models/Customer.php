<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Customer extends Model {
    use SoftDeletes;
    protected $fillable = ['kode','name','phone','email','address','source'];
    public function deals() { return $this->hasMany(Deal::class); }
    public function generateKode(): string {
        $last = static::withTrashed()->max('id') + 1;
        return 'KFB-'.date('Y').'-'.str_pad($last, 3, '0', STR_PAD_LEFT);
    }
}
