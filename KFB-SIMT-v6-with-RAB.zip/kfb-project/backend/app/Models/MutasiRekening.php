<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class MutasiRekening extends Model {
    protected $table    = 'mutasi_rekening';
    protected $fillable = ['deal_id','input_by','type','kategori','jumlah','keterangan','no_referensi','tanggal'];
    protected $casts    = ['jumlah'=>'integer','tanggal'=>'date'];
    public function deal()    { return $this->belongsTo(Deal::class); }
    public function inputBy() { return $this->belongsTo(User::class,'input_by'); }
}
