<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class JadwalPemasangan extends Model {
    protected $table    = 'jadwal_pemasangan';
    protected $fillable = ['deal_id','tgl_pasang','jam_mulai','tim_pemasangan','alamat_lokasi','catatan_teknis','status','tgl_selesai_aktual'];
    protected $casts    = ['tgl_pasang'=>'date','tgl_selesai_aktual'=>'date'];
    public function deal() { return $this->belongsTo(Deal::class); }
    public function selesai(): void {
        $this->update(['status'=>'selesai','tgl_selesai_aktual'=>now()]);
        $this->deal->update([
            'status'      => 'selesai',
            'garansi_end' => now()->addDays($this->deal->garansi_hari),
        ]);
    }
}
