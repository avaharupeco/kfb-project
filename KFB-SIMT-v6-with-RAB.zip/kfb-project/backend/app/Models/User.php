<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;
    protected $fillable = ['name','email','password','role','is_active'];
    protected $hidden   = ['password','remember_token'];
    protected $casts    = ['is_active'=>'boolean'];

    public function isOwner():bool    { return $this->role === 'owner'; }
    public function isManager():bool  { return $this->role === 'manager'; }
    public function isSales():bool    { return $this->role === 'sales'; }
    public function isAdmin():bool    { return $this->role === 'admin'; }
    public function isProduksi():bool { return $this->role === 'produksi'; }

    public function can_access(array $roles):bool { return in_array($this->role, $roles); }

    public function dealsAsSales()   { return $this->hasMany(Deal::class,'sales_id'); }
    public function dealsAsManager() { return $this->hasMany(Deal::class,'manager_id'); }
    public function absensi()        { return $this->hasMany(Absensi::class); }
}
