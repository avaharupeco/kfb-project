<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Deal extends Model {
    use SoftDeletes;
    protected $fillable = [
        'customer_id','sales_id','manager_id','jenis_furnitur','item_pekerjaan',
        'detail_pekerjaan','jenis_deal','nilai_proyek','dp_amount','status',
        'tgl_persetujuan','garansi_hari','garansi_end','catatan',
    ];
    protected $casts = [
        'tgl_persetujuan' => 'date',
        'garansi_end'     => 'date',
        'nilai_proyek'    => 'integer',
        'dp_amount'       => 'integer',
    ];
    public function customer()  { return $this->belongsTo(Customer::class); }
    public function sales()     { return $this->belongsTo(User::class,'sales_id'); }
    public function manager()   { return $this->belongsTo(User::class,'manager_id'); }
    public function rab()       { return $this->hasOne(Rab::class); }
    public function bahan()     { return $this->hasMany(Bahan::class); }
    public function jadwal()    { return $this->hasMany(JadwalPemasangan::class); }
    public function mutasi()    { return $this->hasMany(MutasiRekening::class); }
    public function pettyCash() { return $this->hasMany(PettyCash::class); }
    public function sisa(): int { return max(0, $this->nilai_proyek - $this->dp_amount); }
    public function garansiAktif(): bool {
        return $this->status === 'selesai' && $this->garansi_end && $this->garansi_end->isFuture();
    }
}
