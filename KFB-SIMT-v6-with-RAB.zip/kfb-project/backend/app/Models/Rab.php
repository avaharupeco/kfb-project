<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Rab extends Model {
    protected $table = 'rabs';
    protected $fillable = [
        'deal_id',
        'pekerjaan',
        'item_pekerjaan',
        'detail_pekerjaan',
        'waktu_pengerjaan',
        'cost_material',
        'cost_labor',
        'cost_finishing',
        'cost_other',
        'total',
        'status',
    ];
    protected $casts = [
        'cost_material'    => 'integer',
        'cost_labor'       => 'integer',
        'cost_finishing'   => 'integer',
        'cost_other'       => 'integer',
        'total'            => 'integer',
        'waktu_pengerjaan' => 'integer',
    ];
    public function deal() { return $this->belongsTo(Deal::class); }
    public function recalc(): void {
        $this->total = $this->cost_material + $this->cost_labor + $this->cost_finishing + $this->cost_other;
        $this->save();
    }
}
