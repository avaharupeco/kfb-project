# KFB SIMT — Kurnia Furniture Bogor
## Sistem Informasi Manajemen Terintegrasi

---

## Struktur Proyek (Frontend & Backend TERPISAH)

```
kfb-project/
└── backend/                      ← Laravel 11 (PHP)
    │
    ├── public/                   ← FILE YANG DIKIRIM KE BROWSER
    │   ├── css/
    │   │   └── app.css           ← Semua styling (terpisah dari HTML)
    │   ├── js/
    │   │   └── app.js            ← Semua interaktivitas JS (terpisah)
    │   └── index.php             ← Entry point Laravel
    │
    ├── resources/views/          ← FRONTEND (Template Blade)
    │   ├── layouts/
    │   │   └── app.blade.php     ← Layout utama (sidebar, topbar)
    │   ├── auth/
    │   │   └── login.blade.php   ← Halaman login
    │   ├── dashboard/
    │   │   ├── owner.blade.php   ← Dashboard khusus Owner
    │   │   ├── manager.blade.php ← Dashboard khusus Manager
    │   │   ├── sales.blade.php   ← Dashboard khusus Sales
    │   │   ├── admin.blade.php   ← Dashboard khusus Admin
    │   │   └── produksi.blade.php← Dashboard khusus Tim Produksi
    │   ├── deals/
    │   │   ├── index.blade.php   ← Daftar semua deal
    │   │   └── create.blade.php  ← Form input deal baru
    │   ├── bahan/
    │   │   └── index.blade.php   ← Kebutuhan bahan produksi
    │   ├── jadwal/
    │   │   └── index.blade.php   ← Jadwal pemasangan
    │   ├── absen/
    │   │   └── index.blade.php   ← Absensi karyawan
    │   ├── petty/
    │   │   └── index.blade.php   ← Petty cash harian
    │   └── mutasi/
    │       └── index.blade.php   ← Mutasi rekening bank
    │
    ├── app/                      ← BACKEND (PHP/Laravel)
    │   ├── Http/
    │   │   ├── Controllers/
    │   │   │   ├── AuthController.php
    │   │   │   ├── DashboardController.php
    │   │   │   ├── DealController.php
    │   │   │   ├── BahanController.php
    │   │   │   ├── JadwalController.php
    │   │   │   ├── AbsensiController.php
    │   │   │   ├── PettyCashController.php
    │   │   │   └── MutasiController.php
    │   │   └── Middleware/
    │   │       └── CheckRole.php ← Penjaga akses per role
    │   └── Models/
    │       ├── User.php
    │       ├── Customer.php
    │       ├── Deal.php          ← Model utama (pesanan/proyek)
    │       ├── Bahan.php
    │       ├── JadwalPemasangan.php
    │       ├── Absensi.php
    │       ├── PettyCash.php
    │       └── MutasiRekening.php
    │
    ├── database/                 ← DATABASE
    │   ├── migrations/
    │   │   └── 2024_01_01_000001_create_kfb_tables.php  ← Semua tabel MySQL
    │   └── seeders/
    │       └── DatabaseSeeder.php ← Data awal (5 user + sample data)
    │
    ├── routes/
    │   └── web.php               ← Semua URL / routing
    │
    ├── .env.example              ← Template konfigurasi (copy jadi .env)
    └── composer.json             ← Dependensi PHP
```

---

## Cara Setup & Jalankan

### 1. Install tools yang dibutuhkan

| Tool | Download | Keterangan |
|------|----------|------------|
| Laragon | https://laragon.org | Include PHP 8.2 + MySQL 8 + phpMyAdmin |
| Composer | https://getcomposer.org | Package manager PHP |
| Git | https://git-scm.com | Version control |
| VS Code | https://code.visualstudio.com | Code editor |

### 2. Setup project

```bash
# Masuk ke folder backend
cd kfb-project/backend

# Install dependensi Laravel
composer install

# Copy dan konfigurasi .env
cp .env.example .env
php artisan key:generate
```

Edit `.env`:
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=kfb_simt
DB_USERNAME=root
DB_PASSWORD=
```

### 3. Buat database

Buka **http://localhost/phpmyadmin** → New → nama: `kfb_simt` → collation: `utf8mb4_unicode_ci`

Atau via terminal:
```bash
mysql -u root -e "CREATE DATABASE kfb_simt CHARACTER SET utf8mb4;"
```

### 4. Jalankan migration + seeder

```bash
php artisan migrate:fresh --seed
```

Output yang benar:
```
✓  KFB SIMT seeding selesai!
Login credentials:
  owner@kfb.com    / password  → Owner
  manager@kfb.com  / password  → Manager
  sales@kfb.com    / password  → Sales
  admin@kfb.com    / password  → Admin
  produksi@kfb.com / password  → Tim Produksi
```

### 5. Jalankan server

```bash
php artisan serve
```

Buka: **http://127.0.0.1:8000**

---

## Akun Login

| Email | Password | Role | Akses |
|-------|----------|------|-------|
| owner@kfb.com | password | Owner | Dashboard omzet, laporan, arus kas |
| manager@kfb.com | password | Manager | Proyek, RAB, laporan gaji |
| sales@kfb.com | password | Sales | Input deal, garansi customer |
| admin@kfb.com | password | Admin | Database, absensi, petty cash, mutasi |
| produksi@kfb.com | password | Tim Produksi | Bahan, jadwal pemasangan, kanban |

---

## Pemisahan Frontend & Backend

| Layer | Lokasi | Teknologi |
|-------|--------|-----------|
| **Styling (CSS)** | `public/css/app.css` | CSS murni, diload oleh semua halaman |
| **Interaktivitas (JS)** | `public/js/app.js` | Vanilla JS, diload oleh semua halaman |
| **Template (HTML)** | `resources/views/*.blade.php` | Blade (Laravel) — hanya struktur HTML |
| **Logika (PHP)** | `app/Http/Controllers/` | PHP Controller — handle data & logika |
| **Data** | `app/Models/` | Eloquent Model — hubungan ke database |
| **Database** | `database/migrations/` | MySQL — semua tabel didefinisikan di sini |
| **URL** | `routes/web.php` | Routing Laravel |

---

## Catatan Penting

- **Tidak ada Docker** — langsung jalankan di Laragon/XAMPP
- **Database MySQL** — bukan PostgreSQL, bukan SQLite
- **Tidak ada UUID** — semua primary key BIGINT auto-increment
- **CSS terpisah** — tidak ada `style` inline besar dalam blade
- **JS terpisah** — tidak ada script besar dalam blade
- **Role-based access** — setiap halaman ada pengecekan role via middleware
